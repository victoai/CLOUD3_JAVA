package day12.상속_정보란_실습;

public class 고양이키우기 {
	
	public void 분유먹이기() {
		System.out.println("분유 먹이기");
	}
	
	public void 화장실청소() {
		System.out.println("화장실 청소");
	}
	
	public void 사냥놀이하기() {
		System.out.println("사냥놀이 하기");
	}

}
