package day12.상속_정보란_실습;

public class Baby_cat extends 고양이키우기 {
	
	public void 분유먹을준비() {
		System.out.println("분유를 기다린다");
	}
	
	@Override
	public void 분유먹이기() {
		System.out.println("냐아아아ㅏㅇ!!!");
	}

}
