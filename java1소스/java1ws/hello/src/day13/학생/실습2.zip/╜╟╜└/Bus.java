package day12.상속_inheritance.실습;

public class Bus extends Transportation {

    public Bus(String name) {
        super(name);
    }

    @Override
    public void move() {
        System.out.println(name + "가 버스 전용 차로에서 달립니다.");
    }
}