package day12.상속_inheritance.실습;

public class Car extends Transportation {

    public Car(String name) {
        super(name);
    }

    @Override
    public void move() {
        System.out.println(name + "가 도로에서 달립니다.");
    }
}