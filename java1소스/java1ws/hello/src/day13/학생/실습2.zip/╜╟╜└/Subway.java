package day12.상속_inheritance.실습;

public class Subway extends Transportation {

    public Subway(String name) {
        super(name);
    }

    @Override
    public void move() {
        System.out.println(name + "이 지하철 선로를 따라 달립니다.");
    }
}