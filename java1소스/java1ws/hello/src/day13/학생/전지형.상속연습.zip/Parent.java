package day12.상속.연습;

public class Parent {
	
	public void 애키우기() {
		System.out.println("교대근무로 애를 키운다");
	}
	public void 애키우기_기저귀갈기() {
		System.out.println("기저귀를 간다");
	}
	public void 애키우기_애재우기() {
		System.out.println("아기를 재운다");
	}
	public void 애키우기_애트름시키기() {
		System.out.println("트림을 강제로 시킨다");
	}
	public void 애키우기_분유먹이기() {
		System.out.println("분유를 먹인다");
	}
}
