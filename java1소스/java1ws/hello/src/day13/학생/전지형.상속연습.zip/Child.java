package day12.상속.연습;

public class Child extends Parent {

	@Override
	public void 애키우기_애재우기() {
		System.out.println("baby꿀잠");
	}

	// syso 컨트롤 스페이스

	@Override
	public void 애키우기_기저귀갈기() {
		// TODO Auto-generated method stub
		System.out.println("baby쾌적");
	}
	
	@Override
	public void 애키우기_애트름시키기() {
		// TODO Auto-generated method stub
		System.out.println("baby트름시원");
	}
	
	@Override
	public void 애키우기_분유먹이기() {
		// TODO Auto-generated method stub
		System.out.println("baby야미");
	}
	
	@Override
	public void 애키우기() {
		// TODO Auto-generated method stub
		System.out.println("baby무럭무럭자란다");
	}
	
}