package atm;

import java.util.ArrayList;
import java.util.Scanner;

public class ManageSystem {
	
	Scanner sc = new Scanner(System.in);
	ArrayList<Account> arr = new ArrayList<>();
	
	// 옵션 선택창
	public void printExplain() {
		System.out.println("-------------------------------------");
		System.out.print("  1. 계좌 개설         ");
		System.out.println("2. 입금");
		System.out.print("  3. 출금              ");
		System.out.println("4. 송금");
		System.out.print("  5. 잔액 조회         ");
		System.out.println("6. 종료");
		System.out.println("-------------------------------------");
	}
	
	// 계좌 개설 기능
	public void makeAccount() {
		System.out.println();
		System.out.println("-------------------------------------");
		System.out.print("  이름을 입력해주세요 : ");
		String name = sc.nextLine();
		System.out.print("  비밀번호를 입력해주세요 : ");
		int passwd = sc.nextInt();
		sc.nextLine();
		
		arr.add(new Account(name, passwd));
		System.out.println("  계좌 개설이 완료되었습니다!");
		System.out.println("-------------------------------------\n");
	}
	
	// 입금 기능
	public void deposit() {
		System.out.println();
		System.out.println("-------------------------------------");
		System.out.print("  이름을 입력해주세요 : ");
		String name = sc.nextLine();
		
		// 계좌가 있다면 해당 인덱스를 반환, 없다면 -1을 반환
		int index = checkName(name);
		
		if(index != -1) {
			System.out.print("  금액을 입력해주세요 : ");
			int inputMoney = sc.nextInt();
			sc.nextLine();
			
			// 배열로부터 위치를 가져와서 해당 계좌의 잔액을 현재 잔액에 입금한만큼을 합쳐서 설정
			arr.get(index).setMoney(arr.get(index).getMoney() + inputMoney);
			System.out.println("  현재 잔액은 " + arr.get(index).getMoney() + "원 입니다.");
		} else {
			System.out.println("  계좌가 없습니다.");
		}
		System.out.println("-------------------------------------\n");
		
	}
	
	// 출금 기능
	public void withdraw() {
		System.out.println();
		System.out.println("-------------------------------------");
		System.out.print("  이름을 입력해주세요 : ");
		String name = sc.nextLine();
		
		int index = checkName(name);
		
		if(index != -1) {
			System.out.print("  비밀번호를 입력해주세요 : ");
			int passwd = sc.nextInt();
			sc.nextLine();
			
			// 계좌의 비밀번호가 일치하는지 확인, 있다면 true를 없다면 false를 반환
			boolean check = checkPasswd(index, passwd);
			if(check) {
				System.out.print("  금액을 입력해주세요 : ");
				int inputMoney = sc.nextInt();
				sc.nextLine();
				
				// 만약 현재 계좌의 잔액이 출금하려는 금액보다 적다면
				if(inputMoney > arr.get(index).getMoney()) {
					System.out.println("  잔액이 부족합니다.");
				} else {
					arr.get(index).setMoney(arr.get(index).getMoney() - inputMoney);
					System.out.println("  출금이 완료되었습니다.");
					System.out.println("  현재 잔액은 " + arr.get(index).getMoney() + "원 입니다.");
				}
			} else {
				System.out.println("  비밀번호가 일치하지 않습니다.");
			}
		} else {
			System.out.println("  계좌가 없습니다.");
		}
		System.out.println("-------------------------------------\n");
		
		
	}
	
	// 송금 기능
	public void transfer() {
		System.out.println();
		System.out.println("-------------------------------------");
		System.out.print("  이름을 입력해주세요 : ");
		String name = sc.nextLine();
		
		int index = checkName(name);
		if(index != -1) {
			System.out.print("  비밀번호를 입력해주세요 : ");
			int passwd = sc.nextInt();
			sc.nextLine();
			
			boolean check = checkPasswd(index, passwd);
			
			if(check) {
				System.out.print("  수신자 이름을 입력해주세요 : ");
				String receiver = sc.nextLine();
				int receiverIndex = checkName(receiver);
				
				// 수신자의 계좌가 존재하는지 확인
				if(receiverIndex != -1) {
					System.out.print("  금액을 입력해주세요 : ");
					int money = sc.nextInt();
					sc.nextLine();
					
					if(money > arr.get(index).getMoney()) {
						System.out.println("  잔액이 부족합니다.");
					} else {
						// 송신자의 액수는 차감하고 수신자의 액수는 합산
						arr.get(index).setMoney(arr.get(index).getMoney() - money);
						arr.get(receiverIndex).setMoney(arr.get(receiverIndex).getMoney() + money);
						System.out.println("  송금이 완료되었습니다.");
						System.out.println("  현재 잔액은 " + arr.get(index).getMoney() + "원 입니다.");
					}
				} else {
					System.out.println("  수신자 이름을 확인해주세요.");
				}
			}  else {
				System.out.println("  비밀번호가 일치하지 않습니다.");
			}
		} else {
			System.out.println("  계좌가 없습니다.");
		}
		System.out.println("-------------------------------------\n");
	}
	
	// 잔액 조회 기능
	public void viewAccount() {
		System.out.println();
		System.out.println("-------------------------------------");
		System.out.print("  이름을 입력해주세요 : ");
		String name = sc.nextLine();
		
		int index = checkName(name);
		
		if(index != -1) {
			System.out.print("  비밀번호를 입력해주세요 : ");
			int passwd = sc.nextInt();
			sc.nextLine();
			
			boolean check = checkPasswd(index, passwd);
			
			if(check) {
				System.out.println("  현재 잔액은 " + arr.get(index).getMoney() + "원 입니다.");
			} else {
				System.out.println("  비밀번호가 일치하지 않습니다.");
			}
		} else {
			System.out.println("  계좌가 없습니다.");
		}
		System.out.println("-------------------------------------\n");
	}
	
	// 이름에 해당하는 계좌가 있는지 확인하는 기능
	public int checkName(String name) {
		int index = -1;
		for(int i = 0; i < arr.size(); i++) {
			if(arr.get(i).getName().equals(name)) {
				index = i;
				break;
			}
		}
		return index;
	}
	
	// 계좌의 비밀번호가 일치하는지 확인하는 기능
	public boolean checkPasswd(int index, int passwd) {
		if(arr.get(index).getPassword() == passwd) {
			return true;
		} else {
			return false;
		}
	}
}
