package atm;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		ManageSystem manage = new ManageSystem();
		Scanner sc = new Scanner(System.in);

		
		loop: while (true) {
			manage.printExplain();
			System.out.print(">>> ");
			int select = sc.nextInt();
			sc.nextLine();
			switch(select) {
			case 1:
				manage.makeAccount();
				break;
			case 2:
				manage.deposit();
				break;
			case 3:
				manage.withdraw();
				break;
			case 4:
				manage.transfer();
				break;
			case 5:
				manage.viewAccount();
				break;
			case 6:
				break loop;
			}
		}
		
		System.out.println();
		System.out.println("시스템이 종료되었습니다.");
		sc.close();
		
	}
}
