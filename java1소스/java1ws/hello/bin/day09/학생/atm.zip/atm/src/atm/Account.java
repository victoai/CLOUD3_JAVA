package atm;

public class Account {
	private String name;
	private int money;
	private int password;
	
	public Account() {
		super();
	}
	
	public Account(String name, int password) {
		super();
		this.name = name;
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public int getPassword() {
		return password;
	}

	public void setPassword(int password) {
		this.password = password;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "소유주 : " + name + "\n금액 : " + money + "\n비밀번호 : " + password + "\n";
	}
}
