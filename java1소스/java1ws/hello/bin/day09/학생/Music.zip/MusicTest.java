package day09.성적;

public class MusicTest {

	public static void main(String[] args) {
		
		Music[] music = new Music[7];
		music[0]= new Music("한 페이지가 될 수 있게", "데이식스", 2019, "대한민국", "록");
		music[1]= new Music("Not Like Us", "Kendrick Lamar", 2024, "미국", "힙합");
		music[2]= new Music("Supernatural", "뉴진스", 2024, "대한민국", "K-POP");
		music[3]= new Music("ETA", "뉴진스", 2023,"대한민국" , "K-POP");
		music[4]= new Music("Viva la Vida", "Coldplay", 2008,"영국" , "록");
		music[5]= new Music("예뻤어", "데이식스", 2017,"대한민국" , "록");
		music[6]= new Music("거리에서", "성시경", 2006,"대한민국" , "발라드");
		
		System.out.println("=====곡 목록=====");
		Play.printMusic(music);
		
		Play.play(music);
		
		
	}

}