package day09.성적;

public class Music {

	String title;
	String singer;
	int year;
	String country;
	String genre;
	
	public Music(String title, String singer, int year, String country, String genre) {
		this.title = title;
		this.singer = singer;
		this.year = year;
		this.country = country;
		this.genre = genre;
	}
	
	public void info() {
		System.out.println(title + " | " + singer + " | " + year + " | " + country + " | " + genre);
	}
	
	
	
	
}
