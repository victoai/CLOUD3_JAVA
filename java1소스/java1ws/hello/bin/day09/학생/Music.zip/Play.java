package day09.성적;

import java.util.Scanner;

public class Play {
	
	public static void printMusic(Music[] music) {
		for(Music m : music) {
			m.info();
//			System.out.print(m.info());
			System.out.println();
		}
	}

	public static void play(Music[] music) {
		Scanner sc = new Scanner(System.in);
		
		int index = 0;
		int menu = 0;
		loop:while(true) {
			System.out.println();
			System.out.println("(1 : 현재곡  , 2 : 이전곡,  3 : 다음곡, 4 : 랜덤곡 , 5 : 종료)");
			System.out.print("재생하시고 싶은 곡 : ");
			menu = sc.nextInt();
			sc.nextLine();
			switch(menu) {
			case 1:
				music[index].info();
//				System.out.println(music[index].info());
				break;
			case 2:
				if(index==0) {
					index = music.length-1;
					music[index].info();
//					System.out.println(music[index].info());
				}else {
					index--;
					music[index].info();
//					System.out.println(music[index].info());
				}
				break;
			case 3:
				if(index==music.length-1) {
					index = 0;
					music[index].info();
//					System.out.println(music[index].info());
				}else {
					index++;
					music[index].info();
//					System.out.println(music[index].info());
				}
				break;
			case 4:
				index = (int)(Math.random()*(music.length-1));
				music[index].info();
//				System.out.println(music[index].info());
				break;
			case 5:
				System.out.println();
				System.out.println("종료");
				break loop;
			default :
				System.out.println("입력 오류");
			}
			
		}
	}
}
