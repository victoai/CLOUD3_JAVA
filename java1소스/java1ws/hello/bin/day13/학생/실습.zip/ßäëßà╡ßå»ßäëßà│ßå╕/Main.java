package day12.실습;

public class Main {

	public static void main(String[] args) {

		SmartPhone[] opr = new SmartPhone[2];

		opr[0] = new Android();
		opr[1] = new IOS();

		for (int i = 0; i < opr.length; i++) {
			if (opr[i] instanceof IOS) {
				((IOS) opr[i]).Opr();
			} else {
				((Android) opr[i]).Opr();
			}
			System.out.println();
			opr[i].Call();
			opr[i].Text();
			opr[i].Interface();
			opr[i].Application();
			opr[i].Hardware();
			opr[i].Security();
			opr[i].Update();

		}
	}

}
