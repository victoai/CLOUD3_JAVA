package day12.실습;

public class Android extends SmartPhone {
	public void Opr() {
		System.out.println("< Android >");
	}
	@Override
	public void Interface() {
		System.out.println(
				"안드로이드는 다양한 제조사와 모델에서 사용되기 때문에 사용자 인터페이스가 다양합니다. 사용자는 홈 화면을 원하는 대로 사용자 정의할 수 있고, 다양한 위젯과 아이콘을 배치할 수 있습니다.");
	}

	@Override
	public void Application() {
		System.out.println(
				"Google Play 스토어에서는 다양한 앱이 제공되며, 업데이트 및 변경사항을 빠르게 반영할 수 있습니다. 다양한 앱스토어들을 통해 다양한 소스에서 앱을 다운로드할 수 있습니다.");
	}

	@Override
	public void Hardware() {
		System.out.println("다양한 제조사와 모델에서 안드로이드를 사용하고 있어 다양한 가격대와 사양의 기기를 선택할 수 있습니다.");
	}

	@Override
	public void Security() {
		System.out.println("Google은 안드로이드를 통해 수많은 데이터를 수집하지만, 최근 버전에서는 사용자에게 더 많은 개인정보 컨트롤 권한을 부여하고 있습니다.");
	}
	
	@Override
	public void Update() {
		System.out.println("하드웨어 제조사 및 통신사에 따라 업데이트의 지연이 발생할 수 있습니다. 오래된 기기는 새로운 안드로이드 버전을 지원하지 않을 수 있습니다.");
	}
}
