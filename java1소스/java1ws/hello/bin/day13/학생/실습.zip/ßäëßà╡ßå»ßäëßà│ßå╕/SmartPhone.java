package day12.실습;

public class SmartPhone {

	public void Call() {
		System.out.println("통화 기능");
	}

	public void Text() {
		System.out.println("문자 기능");
	}

	public void Interface() {
		System.out.println("인터페이스 구성");

	}

	public void Application() {
		System.out.println("애플리케이션");
	}

	public void Hardware() {
		System.out.println("하드웨어");
	}

	public void Security() {
		System.out.println("보안 및 개인정보");
	}

	public void Update() {
		System.out.println("업데이트 및 지원");
	}
}
