package day12.실습;

public class IOS extends SmartPhone {

	public void Opr() {
		System.out.println("< IOS >");
	}

	@Override
	public void Interface() {
		System.out.println("iOS는 애플의 엄격한 통제 아래에서 개발되며, 일관된 사용자 경험을 제공합니다. 아이콘 정렬은 제한적이지만, 심플하고 직관적인 디자인이 특징입니다.");
	}

	@Override
	public void Application() {
		System.out.println(
				"애플 앱스토어는 엄격한 심사 과정을 거쳐 안정성과 보안을 보장하며, 앱의 일관된 품질을 유지합니다. 다만, 앱의 업데이트 및 변경사항 반영이 상대적으로 더 느릴 수 있습니다.");
	}

	@Override
	public void Hardware() {
		System.out.println("iOS는 애플 제품군에서만 사용 가능하므로, iPhone, iPad, iPod Touch와 같은 한정적인 기기에서만 이용할 수 있습니다.");
	}

	@Override
	public void Security() {
		System.out.println("애플은 개인정보 보호에 강조를 두고 있으며, Face ID 및 Touch ID와 같은 생체 인식 기술을 사용하여 높은 보안 수준을 제공합니다.");
	}

	@Override
	public void Update() {
		System.out.println("애플은 iOS 업데이트를 직접 제어하므로 대부분의 기기에 신속하게 배포됩니다. 오래된 기기도 최신 버전의 iOS를 받을 수 있는 경우가 많습니다.");

	}
}
