package day11.ex;

public class Main {

	public static void main(String[] args) {
		DayPlanner dp = new DayPlanner();
		dp.run();
	}

}
