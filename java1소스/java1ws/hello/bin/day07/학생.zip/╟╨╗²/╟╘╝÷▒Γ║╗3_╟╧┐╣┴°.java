package day07.학생;

public class 함수기본3_하예진 {

	public static void main(String[] args) {
		int result = 투자(30000);
		System.out.println(result);
	}

	public static int 투자(int a) {
		System.out.println(a * 2);
		return a * 2;
	}

}
