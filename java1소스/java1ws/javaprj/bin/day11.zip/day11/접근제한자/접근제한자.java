package day11.접근제한자;

public class 접근제한자 {

	public static void main(String[] args) {
		
		
		//클래스 멤버들의 접근을 허용하는 범위를 결정한다
		
		//private : 클래스 내부에서만 접근을 허용
		//public  : 모두 접근을 허용함 
		//default : 접근제한자를 생략하면  default  접근제한자를 갖는다
		//          같은패키지에서는 접근을 허용함(다른 패키지에 있는 클래스들은 접근 불가, 보이지 않음)
		
		
		//protected: 상속관계에서 접근허용함 
		

	}

}
