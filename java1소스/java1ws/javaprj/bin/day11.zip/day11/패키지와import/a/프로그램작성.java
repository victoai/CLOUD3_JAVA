package day11.패키지와import.a;


import  day11.패키지와import.b.Book ;

public class 프로그램작성 {

	public static void main(String[] args) {


		//클래스정보는  패키지정보와클래스이름까지 포함한다 
		
		//day11.패키지와import.b.Book book = new  day11.패키지와import.b.Book();
		
		Book book = new Book();
		

	}

}
