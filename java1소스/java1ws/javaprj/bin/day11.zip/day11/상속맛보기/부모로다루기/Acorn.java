package day11.상속맛보기.부모로다루기;

public class Acorn {
	
	public void dance() {
		 System.out.println("에이콘 학생은 춤을 춘다");
    }
	

}
