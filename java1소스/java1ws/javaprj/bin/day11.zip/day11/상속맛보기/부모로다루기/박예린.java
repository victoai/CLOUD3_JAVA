package day11.상속맛보기.부모로다루기;

public class 박예린  extends Acorn{
	
	@Override
	public void dance() {
		
		System.out.println("막춤");
		 
	}

}
