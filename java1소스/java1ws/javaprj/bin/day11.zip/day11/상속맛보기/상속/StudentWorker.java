package day11.상속맛보기.상속;

public class StudentWorker  extends  Student {
	
	public void 일하기() {
		System.out.println("일하기");
	}


}
