package teamproject;

public interface Order {

	String Order();

	int cost();

}
