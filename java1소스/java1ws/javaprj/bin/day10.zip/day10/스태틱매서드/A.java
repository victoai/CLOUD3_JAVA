package day10.스태틱매서드;

public class A {
	
	 
	 
	
	public static int add( int a, int b) {	 
	
		return a+b;
	}
	
}
