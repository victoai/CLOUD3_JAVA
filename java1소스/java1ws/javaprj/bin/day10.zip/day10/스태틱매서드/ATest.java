package day10.스태틱매서드;

public class ATest {

	public static void main(String[] args) {


		int result  = A.add(5, 3);
		

	}

}
