package day10.스태틱매서드;

public class C {

	
	public int add( int su1, int su2) {
		return su1+su2;
	}
}
