package day10.스태틱매서드;

public class BTest {

	public static void main(String[] args) {
		 
		
		B b = new B(5,3);
		int result  =b.add();
		
		System.out.println(result);

	}

}
