package day10.스태틱매서드;

public class CTest {

	public static void main(String[] args) {


		C c= new C();
		int result  = c.add(5, 3);
	}

}
