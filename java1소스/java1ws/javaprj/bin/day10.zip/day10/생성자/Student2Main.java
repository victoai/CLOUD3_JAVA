package day10.생성자;

public class Student2Main {

	public static void main(String[] args) {
		
		
		//Student2  s  = new Student2();
		Student2  s= new Student2("홍길동",25);		
 
		s.printInfo();
		 
		

	}

}
