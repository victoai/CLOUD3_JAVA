package day10.학생관리;

public class 학생관리프로그램0 {

	public static void main(String[] args) {

		Student s  = new Student();
		
		 

	}

}
