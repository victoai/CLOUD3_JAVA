package day08.학생_구조화된자료형;

public class 스낵정보_이동우 {

	
	//종류
	//이름
	//가격
	
	String type;
	String name;
	int amount;
}
