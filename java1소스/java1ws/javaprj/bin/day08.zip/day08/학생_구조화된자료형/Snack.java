package day08.학생_구조화된자료형;

public class Snack {

	
	
		
		String name;
		String company;
		String calories;
		String info;
		
		int gram;
		int expDate;
		int bornyear;

	}


