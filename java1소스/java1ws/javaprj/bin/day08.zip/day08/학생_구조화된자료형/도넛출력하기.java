package day08.학생_구조화된자료형;

public class 도넛출력하기 {

public static void main(String[] args) {
 
		Donuts d = new Donuts( "누텔라 카스텔라 도넛" ,  3900,370,200  );	
		
		d.printInfo();  // printInfo(d);
		
		 
		//d.input("누텔라 카스텔라 도넛" ,  3900,370,200);
		//d.input("국밥" ,  3900,370,200);
		

		Donuts d2 = new Donuts();	
		//d.input("왕도넛" ,  2700,370,200);
		
		
		 
	}

	 
}
