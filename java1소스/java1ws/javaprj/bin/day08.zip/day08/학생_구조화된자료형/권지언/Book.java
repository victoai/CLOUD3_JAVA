package day08.학생_구조화된자료형.권지언;

public class Book {
	String book_name;
	String author;
	int price;
}
