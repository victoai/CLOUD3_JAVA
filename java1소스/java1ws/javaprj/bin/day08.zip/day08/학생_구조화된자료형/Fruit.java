package day08.학생_구조화된자료형;

public class Fruit {

	String name;
	String flavor;
}
