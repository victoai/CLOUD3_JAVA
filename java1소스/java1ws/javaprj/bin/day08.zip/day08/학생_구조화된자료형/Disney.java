package day08.학생_구조화된자료형;

public class Disney {

	String title;
	String title_eng;
	String release;
	double rating;
	int viewers;
	
	
	
	
	
	
	
}
