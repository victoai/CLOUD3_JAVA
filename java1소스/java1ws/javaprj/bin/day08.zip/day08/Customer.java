package day08;


//사용자정의 자료형  (type)
//사용자정의 자료형의 명세 (스펙, 틀)만들기


//오해금지: 변수가 만들어진것이 아니다 
//고객정보를 저장할 자료형을 정의하는 것이다
public class Customer {
	
	String name;
	String address;
	int age;

}
