package day08;

public class WJY {
	
	//
	
	public static  int adder( int su1, int su2) {
		return su1+su2;
	}

}
