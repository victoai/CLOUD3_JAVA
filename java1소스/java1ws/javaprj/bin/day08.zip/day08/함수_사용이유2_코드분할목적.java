package day08;

public class 함수_사용이유2_코드분할목적 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//일정등록하기
		//System.out.println("일정등록하기");
		등록하기();
		
		
		
		//일정조회하기
		//System.out.println("일정조회하기");
		조회하기();
		
		
		//일정변경하기
	     변경하기();
	     

	    //일정삭제하기
		 삭제하기();


	}


	public static void 삭제하기() {
		System.out.println("일정삭제하기");
	}


	public static void 변경하기() {
		System.out.println("일정변경하기");
	}
	
	
	//입력
	//반환
	public static void 등록하기() {
		System.out.println("일정등록하기");
	}
	
	
	
	public static void  조회하기() {
		System.out.println("일정조회하기");		
	}
	
	
	

}
