package day08;

public class 자바라이브러기사용하기 {

	public static void main(String[] args) {
		
		
		//Math클래스의 기능 min, max
		
	 
		int result  = Math.min(5, 3);
		int result2 = Math.max( 5,3);
		
		System.out.println( result);

		System.out.println( result2);

	}

}
