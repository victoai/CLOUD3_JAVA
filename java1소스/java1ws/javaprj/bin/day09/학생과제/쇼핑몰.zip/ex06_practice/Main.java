package chap_07.chap_01_class1.ex06_practice;

public class Main {
    public static void main(String[] args) {
        Shoppingmall information = new Shoppingmall(201803120001L,
                "abc123",
                2018+"년"+3+"월"+12+"일",
                "홍길순",
                "D"+0345+"-"+12,
                "서울시 영등포구 여의도동 20번지"
                );
            information.Intro();
            System.out.println(information.Intro());
    }
}
