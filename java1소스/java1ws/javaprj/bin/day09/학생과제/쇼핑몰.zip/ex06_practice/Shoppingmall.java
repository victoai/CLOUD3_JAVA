package chap_07.chap_01_class1.ex06_practice;
/*
    주문번호: 201803120001
    주문자아이디: abc123
    주문날짜:2018년3월12일
    주문자이름: 홍길순
    주문상품번호😛D0345-12
    배송주소: 서울시 영등포구 여의도동 20번지
*/

public class Shoppingmall {
        long ordNo;
        String userId;
        String date;
        String name;
        String productNO;
        String address;

        Shoppingmall(long ordNo, String userId , String date , String name , String productNO , String address) {
            this.ordNo = ordNo;
            this.userId = userId;
            this.date = date;
            this.name = name;
            this.productNO = productNO;
            this.address = address;
        }

        String Intro(){
            return ("주문번호 : %d \n아이디 : %s\n주문날짜 : %s\n주문자이름 : %s\n주문상품번호:%s\n배송주소:%s"
                    .formatted(ordNo,userId,date,name,productNO,address
            ));

        }
}
