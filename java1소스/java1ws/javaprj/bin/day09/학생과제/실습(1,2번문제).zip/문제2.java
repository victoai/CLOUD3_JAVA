package day09.실습;

public class 문제2 {

	public static void main(String[] args) {
		
		Goods a = new Goods();
		a.input(201803120001l, "abc123", "2018년3월12일", "홍길순", "D0345-12", "서울시 영등포구 여의도동 20번지");
		a.printInfo();
		
		Goods b = new Goods();
		b.scanenr();
		b.printInfo();
	}

}
