package day09.실습;

import java.util.Scanner;

public class Goods {
	long order_num;
	String id;
	String date;
	String name;
	String goods_code;
	String address;

	public void input(long order_num, String id, String date, String name, String goods_code, String address) {
		this.order_num = order_num;
		this.id = id;
		this.date = date;
		this.name = name;
		this.goods_code = goods_code;
		this.address = address;
	}

	public void scanenr() {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("주문번호:");
		this.order_num = sc.nextLong();
		System.out.print("주문자아이디:");
		this.id = sc.next();
		System.out.print("주문날짜(xxxx년x월x일):");
		this.date = sc.next();
		System.out.print("주문자이름:");
		this.name = sc.next();
		System.out.print("주문상품번호:");
		this.goods_code = sc.next();
		sc.nextLine();
		System.out.print("배송주소:");
		this.address = sc.nextLine();
		
		sc.close();
	}
	
	public void printInfo() {
		System.out.println(this.order_num);
		System.out.println(this.id);
		System.out.println(this.date);
		System.out.println(this.name);
		System.out.println(this.goods_code);
		System.out.println(this.address);
	}
	
	
}
