package day09.실습;

import java.util.Scanner;

public class Human {

	String name;
	int age;
	boolean isMarried;
	int chd;

	// 입력하기
	public void input(String name, int age, int chd) {
		this.name = name;
		this.age = age;
		this.chd = chd;
	}

	// 결혼 여부
	public void status() {
		Scanner sc = new Scanner(System.in);
		System.out.print("결혼여부(true or false):");
		isMarried = sc.nextBoolean();
		sc.close();
	}

	// 정보 출력
	public void printInfo() {
		System.out.println(this.name);
		System.out.println(this.age);
		if (isMarried) {
			System.out.println("기혼입니다");
		} else {
			System.out.println("미혼입니다.");
		}
		System.out.println(this.chd);
	}

}
