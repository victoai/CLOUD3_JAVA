package day09.실습;

public class 문제1 {

	public static void main(String[] args) {

		Human a = new Human();
		a.input("james", 40, 3);
		a.status();
		a.printInfo();

	}

}
