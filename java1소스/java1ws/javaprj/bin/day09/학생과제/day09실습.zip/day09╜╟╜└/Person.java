package day09실습;

public class Person {
	private int age;
	private String name;
	private boolean marriage;
	private int child;

	public Person(int age, String name, boolean marriage, int child) {
		this.age = age;
		this.name = name;
		this.marriage = marriage;
		this.child = child;
	}
	
	public void print() {
		System.out.println("이 사람의 나이 : " + this.age);
		System.out.println("이 사람의 이름 : " + this.name);
		System.out.println("이 사람의 결혼여부 : " + this.marriage);
		System.out.println("이 사람의 자녀수 : " + this.child);
	}

}
