package day09실습;

public class Order {
	private String no;
	private String id;
	private String date;
	private String name;
	private String itemNo;
	private String adress;

	public Order(String no, String id, String date, String name, String itemNo, String adress) {
		this.no = no;
		this.id = id;
		this.date = date;
		this.name = name;
		this.itemNo = itemNo;
		this.adress = adress;
	}

	public void print() {
		System.out.println("주문번호: " + this.no);
		System.out.println("주문자아이디: " + this.id);
		System.out.println("주문날짜: " + this.date);
		System.out.println("주문자이름: " + this.name);
		System.out.println("주문상품번호: " + this.itemNo);
		System.out.println("배송주소: " + this.adress);
	}

}
