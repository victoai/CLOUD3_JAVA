package day09실습;

public class 실습객체사용 {

	public static void main(String[] args) {
		Person p = new Person(40, "james", true, 3);
		p.print();
		System.out.println("===============");

		Order o = new Order("201803120001", "abc123", "2018년3월12일", "홍길순", "D0345-12", "서울시 영등포구 여의도동 20번지");
		o.print();
		System.out.println("===============");

		Score s = new Score("홍길동", 90, 80);
		s.print();
		System.out.println("===============");
	}

}
