package chap_07.chap_01_class1.ex04_practice;

public class main {
    public static void main(String[] args) {
        james_information information = new james_information(40,"James",true,3 );

        information.place();
    }
}
