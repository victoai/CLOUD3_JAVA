package chap_07.chap_01_class1.ex04_practice;
//<출력결과>
//나이 : 30
//이름 : James
//결혼여부 : ture
//자녀 수 : 3

public class james_information {

    String name;
    int age;
    int sons;
    boolean married;

       james_information(int age, String name, boolean married, int sons){

        this.age = age;
        this.name = name;
        this.married = married;
        this.sons = sons;
    }

    void place() {
        System.out.printf(
                " 나이 : %d\n 이름 : %s\n 결혼여부 : %b\n 자녀 수 : %s",
                age, name, married, sons // 만약 이렇게 추가 하지 못하면 이 메소드에서 어떠한 것을 출력 해야하는지 모르게 된다.
        );
    }

}
