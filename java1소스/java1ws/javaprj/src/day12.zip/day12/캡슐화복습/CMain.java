package day12.캡슐화복습;

public class CMain {

	public static void main(String[] args) {
		
		
		C  c = new C(3,5);
		
		String 객체내용=c.toString();
		
		System.out.println( 객체내용);

	}

}
