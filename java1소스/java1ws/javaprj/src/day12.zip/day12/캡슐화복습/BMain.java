package day12.캡슐화복습;

public class BMain {

	public static void main(String[] args) {
		
		
		B  b = new B();
		
		b.매서드1();   // 매서드1 호출할때 b객체의 정보가 전달된다
		
		

	}

}
