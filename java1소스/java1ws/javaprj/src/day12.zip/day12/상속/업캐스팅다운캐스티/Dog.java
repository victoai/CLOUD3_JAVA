package day12.상속.업캐스팅다운캐스티;

public class Dog  extends Animal{
	
	 public void 집을지킨다() {
		 System.out.println("집을 지킨다");
	 }

}
