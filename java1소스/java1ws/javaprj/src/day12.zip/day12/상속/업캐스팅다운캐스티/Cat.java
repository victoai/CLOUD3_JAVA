package day12.상속.업캐스팅다운캐스티;

public class Cat extends Animal {
	
	//고유
	
	public void   쥐를잡는다() {
		System.out.println("쥐를 잡는다");
	}

}
