package day12.상속.다형성;

public class Wolf extends Animal {
	
	@Override
	public void 짖다() {
	
		System.out.println("아우~");	}

}
