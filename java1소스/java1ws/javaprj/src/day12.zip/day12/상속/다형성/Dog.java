package day12.상속.다형성;

public class Dog  extends Animal{

	@Override
	public void 짖다() {
		
		System.out.println( "멍멍");
	}
}
