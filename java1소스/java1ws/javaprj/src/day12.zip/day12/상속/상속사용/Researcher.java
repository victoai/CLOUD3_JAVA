package day12.상속.상속사용;

public class Researcher extends Person {
	public void 연구() {
		System.out.println("연구하기");
	}
}
