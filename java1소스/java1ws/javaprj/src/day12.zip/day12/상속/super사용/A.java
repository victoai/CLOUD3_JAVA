package day12.상속.super사용;

public class A {
	
	
	public void 매서드1() {		
		System.out.println("A객체의  매서드1");
	}
	
	public void  매서드2() {
		System.out.println("A객체의  매서드2");
	}
	
	

}
