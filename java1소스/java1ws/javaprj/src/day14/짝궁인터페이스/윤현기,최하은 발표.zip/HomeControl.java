package chap_08_interFace.Day00.Ex03;

public interface HomeControl {

    void turnOn();
	void turnOff();
	void timer();
}
