package chap_08_interFace.Calculator;

public interface Calculator {
	
	int add( int su1, int su2);
	int sub( int su1, int su2);
	int mul( int su1, int su2);
	int div( int su1, int su2);

}
