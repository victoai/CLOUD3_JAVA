package day09;

public class Person {
	public static void main(String[] args) {
		James james = new James();
		james.agePrint();
		james.namePrint();
		james.isMarried();
		james.hasChild();
	}
}
