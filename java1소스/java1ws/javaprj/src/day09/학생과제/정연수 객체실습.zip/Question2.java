package day09;

public class Question2 {

	String orderNum = "201803120001";
	String id = "abc123";
	String date = "2018년3월12일";
	String name = "홍길동";
	String productNum = "D0345-12";
	String home = "서울시 영등포구 여의도동 20번지";
	
	public void order() {
		this.orderNum = orderNum;
		this.id = id;
		this.date = date;
		this.name = name;
		this.productNum = productNum;
		this.home = home;
	}
	
	public void printOrder() {
		System.out.println(orderNum);
		System.out.println(id);
		System.out.println(date);
		System.out.println(name);
		System.out.println(productNum);
		System.out.println(home);
	}
	

}
