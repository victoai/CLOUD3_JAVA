package day09;

public class Question3 {
	String name;
	int kor;
	int eng;
	double avg;
	
	public void scoreInput(String name, int kor, int eng) {
		this.name = name;
		this.kor = kor;
		this.eng = eng;
	}
	
	public void avgCalc() {
		this.avg = (this.kor + this.eng) / 2;
	}
	
	public void printScore() {
		System.out.println(name);
		System.out.println(kor);
		System.out.println(eng);
		System.out.println(avg);
	}

}
