package day09;

public class 실습문제2 {

	public static void main(String[] args) {
		Question2 q2 = new Question2();
		q2.printOrder();

	}

}
