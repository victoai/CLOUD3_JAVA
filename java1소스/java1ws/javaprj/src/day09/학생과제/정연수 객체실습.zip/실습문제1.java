package day09;

public class 실습문제1 {

	public static void main(String[] args) {
		


		Question1 q1 = new Question1();
		q1.inpect(40, "james", true, 3);
		q1.printIns();

	}

}
