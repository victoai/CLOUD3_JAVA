package day09;

public class Question1 {

	int age;
	String name;
	boolean marrige;
	int kids;
	
	
	public void inpect(int age, String name, boolean marrige, int kids) {
		this.age = age;
		this.name = name;
		this.marrige = marrige;
		this.kids = kids;
	}
	
	public void printIns() {
		System.out.println(age);
		System.out.println(name);
		System.out.println(marrige);
		System.out.println(kids);
		
		
	}
}
