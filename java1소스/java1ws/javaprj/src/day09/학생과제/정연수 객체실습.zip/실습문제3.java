package day09;

public class 실습문제3 {

	public static void main(String[] args) {
		Question3 q3 = new Question3();
		q3.scoreInput("김게똥", 98, 94);
		q3.avgCalc();
		q3.printScore();

	}

}
