package day13.objectEx;

public class toString매서드 {

	public static void main(String[] args) {
		
		
		// Object 클래스가 가지는 매서드이다 
		// 우리가 만드는 클래스들은  Object를 상속받게 되어 있다 
		// Object -매서드 (toString() )
		// toString()는 생략된 형태로 사용할 수 있다 
		// 객체의 정보를 제공하는 역할을 하기 때문에 
		// 객체에 맞게 적절하게 오버라이드 해서 사용해야 한다 
		// 부모(Object)클래스의 있는 toString()매서드는 객체정보를 제공한다 

	}

}
