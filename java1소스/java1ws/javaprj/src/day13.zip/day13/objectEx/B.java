package day13.objectEx;

public class B {

	
	@Override
	public String toString() {
		 
		return  "b객체";
	}
	
}
