package day13.춤추기;

public class 오윤석  extends Acorn{

	@Override
	public void dance() {
		// TODO Auto-generated method stub
		System.out.println("셔플");
	}
	
}
