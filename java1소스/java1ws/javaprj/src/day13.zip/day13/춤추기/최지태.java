package day13.춤추기;

public class 최지태 extends Acorn {
  @Override
public void dance() {
	   System.out.println("문워크");
}
}
