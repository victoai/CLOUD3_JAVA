package day13.춤추기;

public class 윤현기  extends Acorn{

	@Override
	public void dance() {
	   System.out.println("나루토 춤으로 부탁드립니다");
	}
}
