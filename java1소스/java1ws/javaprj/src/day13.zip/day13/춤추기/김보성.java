package day13.춤추기;

public class 김보성 extends Acorn{

	 @Override
	public void dance() {
		  System.out.println("스윙");
	}
}
