package day13.춤추기;

public class 박예린  extends Acorn{
	
	@Override
	public void dance() {
		
		System.out.println("막춤");
		 
	}

}
 