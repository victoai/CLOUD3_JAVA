package day13.춤추기;

public class Acorn {
	
	public void dance() {
		 System.out.println("에이콘 학생은 춤을 춘다");
    }
	

}
