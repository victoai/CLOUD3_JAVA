package day13.춤추기;

public class 이수민  extends Acorn{

	 @Override
	public void dance() {
		 System.out.println("부채춤,,");
	}
}
