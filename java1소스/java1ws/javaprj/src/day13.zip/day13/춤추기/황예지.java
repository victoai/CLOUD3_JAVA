package day13.춤추기;

public class 황예지 extends Acorn{
	 @Override
	public void dance() {
		// TODO Auto-generated method stub
		System.out.println("팝핀");
	}

}
