package day13.춤추기;

public class 이동우  extends Acorn {
	
	@Override
	public void dance() {
		  System.out.println( "한국무용");
	}

}
