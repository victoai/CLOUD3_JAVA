package day13.춤추기;

public class 임형택 extends Acorn{

	@Override
	public void dance() {
	    System.out.println( "Baile de los Viejitos de Jarácuaro Michoacán México 입니다");
	}
}
