package day13.춤추기;

public class 김민환  extends Acorn {

}
