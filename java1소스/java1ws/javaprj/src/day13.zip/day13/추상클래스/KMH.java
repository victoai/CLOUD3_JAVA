package day13.추상클래스;

public class KMH extends Acorn{

	@Override
	public void 춤추기() {
		System.out.println("쌈바~~~~~~~");
	}
	
}
