package day13.추상클래스;

public class OYS extends Acorn {

	@Override
	public void 춤추기() {
		System.out.println("셔플댄스를 춘다");
	}

}
