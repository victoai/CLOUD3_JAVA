package day13.추상클래스;

public class HYJ extends Acorn{

	@Override
	public void 춤추기() {
		System.out.println("탈춤을 춘다");
	}
}
