package day13.추상클래스;

public class LJH extends Acorn {

	@Override
	public void 춤추기() {
		System.out.println("탭댄스를 춘다");
		
	}
	
}
