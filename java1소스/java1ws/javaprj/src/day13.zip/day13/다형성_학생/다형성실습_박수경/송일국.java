package day13.다형성_학생.다형성실습_박수경;

public class 송일국 {
	public void say() {
		System.out.println("얘들아");
	}
}
