package day13.다형성_학생.다형성실습_박수경;

public class 송만세 extends 송일국{		//상속

	@Override
	public void say() {
		System.out.println("네 셋째입니다");
	}
}
