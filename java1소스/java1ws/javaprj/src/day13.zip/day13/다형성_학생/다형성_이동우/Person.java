package day13.다형성_학생.다형성_이동우;

public class Person {

	String name;
	
	
	public Person() {
		
	}
	
	public Person(String name) {
		this.name = name;
		
	}

	public void personInfo() {
		System.out.println("사람들은 모두 다양한 역할의 일을 한다.");
	}
}
