package day13.다형성_학생.다형성_오윤석;

public class Radio extends Content {

	@Override
	public void play() {
		System.out.println("라디오를 청취합니다");
	}

}
