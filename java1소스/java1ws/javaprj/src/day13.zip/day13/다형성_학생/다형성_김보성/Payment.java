package day13.다형성_학생.다형성_김보성;

public class Payment {
	
	public void pay(int Payment) {
		System.out.println(Payment + "원 결제 예정. ");
	}
	
}
