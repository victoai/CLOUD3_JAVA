package day13.다형성.음료마시기;

class AcornStudent{
	
    public void 음료마시기(){  
               System.out.println("음료마시기 기능을 자신에 맞게 오버라이드 하세요");
    }
}
