package day13.다형성.음료마시기;

public class 음료_박수경 extends AcornStudent{
	@Override
	public void 음료마시기() {
		System.out.println("아이스 아메리카노 부탁드립니다,,, 감사합니다");
	}
}
