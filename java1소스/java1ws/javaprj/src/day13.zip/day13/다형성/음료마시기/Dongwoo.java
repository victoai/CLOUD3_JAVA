package day13.다형성.음료마시기;

public class Dongwoo extends AcornStudent{

	@Override
	public void 음료마시기() {
		System.out.println("동우는 아메리카노를 진짜 완전 엄청 좋아합니다. 아~메~리~카~노~!!!!!!!!");
	}
	
}
