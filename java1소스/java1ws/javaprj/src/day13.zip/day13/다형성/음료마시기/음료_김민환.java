package day13.다형성.음료마시기;

public class 음료_김민환 extends AcornStudent{

	@Override
	public void 음료마시기(){  
        System.out.println("김민환: 카페라떼");
	}
	
}
