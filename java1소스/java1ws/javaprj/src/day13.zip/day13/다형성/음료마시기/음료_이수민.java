package day13.다형성.음료마시기;

public class 음료_이수민 extends AcornStudent{
	
	@Override
	public void 음료마시기(){  
        System.out.println("수민이는 아이스아메리카노를 마실게요..^^");
	}
}
