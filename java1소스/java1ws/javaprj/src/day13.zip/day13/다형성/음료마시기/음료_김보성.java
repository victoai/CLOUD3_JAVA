package day13.다형성.음료마시기;

public class 음료_김보성 extends AcornStudent{

	@Override
	public void 음료마시기() {
		System.out.println("김보성(는)은 갈아만든배를 마시고 싶어요.");
	}
	
}
