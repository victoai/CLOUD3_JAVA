package day13.다형성.음료마시기;

public class 최지태 extends AcornStudent {
	@Override
	public void 음료마시기() {
		System.out.println("최지태는 아메리카노를 먹고싶어요");
	}
}