package day13.다형성.음료마시기;

public class 음료_황예지 extends AcornStudent {

	
	@Override
	public void 음료마시기() {
		System.out.println("황예지, 저는 아이스티용");
	}
}
