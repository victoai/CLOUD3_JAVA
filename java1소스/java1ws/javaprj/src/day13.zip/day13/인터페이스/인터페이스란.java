package day13.인터페이스;


public class 인터페이스란 {

	public static void main(String[] args) {

		
		//추상매서드만으로 구성된 클래스는 인터페이스라고 한다 
		//interface 인터페이스명 {}
		//인터페이스 상속은  extends 아니라  implements 키워드를 사용한다 
		//인터페이스는 여러개 상속할 수 있다 
		

	}

}
