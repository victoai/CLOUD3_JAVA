package day13.인터페이스;

public class Cook   implements 전투가능한{
	
	 public void  피자만들기() {
		 
		 System.out.println("피자만들기");
	 }

	@Override
	public void 싸운다() {
		 
		 System.out.println("후라이팬을 가지고 싸운다 ");
		
	}

}
