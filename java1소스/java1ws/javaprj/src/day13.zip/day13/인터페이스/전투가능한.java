package day13.인터페이스;


//
//인터페이스는 추상매서드만 가지고 있기 때문에  abstract 키워드 생략된 형태로 사용

public interface 전투가능한 {
	public  void 싸운다();
	//public abstract   void 싸운다() ;
}
