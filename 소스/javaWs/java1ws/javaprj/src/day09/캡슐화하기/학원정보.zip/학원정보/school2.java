package day09;
import java.util.Scanner;
public class school2
{
	public static void main(String[] args) {
		school a = new school();

		a.setSchool();
		a.printSchool();
	}
}
