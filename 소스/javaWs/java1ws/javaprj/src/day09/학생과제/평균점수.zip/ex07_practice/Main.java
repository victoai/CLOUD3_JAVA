package chap_07.chap_01_class1.ex07_practice;

public class Main {
    public static void main(String[] args) {
        Grade score = new Grade("윤현기",90,80,90+80,170/2);

        score.Intro();

        System.out.println(score.Intro());
    }
}
