package chap_07.chap_01_class1.ex07_practice;
//3. 학생성적을 담을  class  작성하기
 //Score 이름으로 작성하시오
  // - name 학생이름
  // - kor  국어성적
  // - eng 영어성적
  // - avg 평균
public class Grade {
    String name;
    int kor;
    int eng;

    int hap;
    double avg;

    Grade(String name, int kor ,int eng,int hap,double avg){
        this.name = name;
        this.kor = kor;
        this.eng = eng;
        this.hap = hap;
        this.avg = avg;
    }

    String Intro(){
        return ("학생이름:%s\n국어점수:%d\n영어점수:%d\n합계:%d\n평균:%2f"
                .formatted(name,kor,eng,hap,avg
                ));
    }

}
