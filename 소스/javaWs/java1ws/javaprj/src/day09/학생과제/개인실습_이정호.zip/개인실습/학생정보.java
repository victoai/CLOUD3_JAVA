package 개인실습;

public class 학생정보 {

	public static void main(String[] args) {
		Student st = new Student();
		
		st.Input();
		System.out.println("==========");
		st.PrintInfo();
	}

}
