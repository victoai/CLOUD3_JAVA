package 개인실습;

public class 주문정보 {

	public static void main(String[] args) {
		Order order = new Order();
		
		order.Input();
		order.PrintInfo();

	}

}
