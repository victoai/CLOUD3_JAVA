package 개인실습;

public class 사람정보 {

	public static void main(String[] args) {
		Human human = new Human();
		
		human.Input(40, "james", true, 3);
		human.PrintInfo();

	}

}
