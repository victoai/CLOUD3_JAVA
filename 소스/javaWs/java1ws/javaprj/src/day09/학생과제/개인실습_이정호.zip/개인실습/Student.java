package 개인실습;

import java.util.Scanner;

public class Student {
	Scanner scan = new Scanner(System.in);
	
	private String name;
	private int kor;
	private int eng;
	private double avg;
	
	public void Input() {
		System.out.print("학생이름 : ");
		this.name = scan.next();
		System.out.print("국어성적 : ");
		this.kor = scan.nextInt();
		System.out.print("영어성적 : ");
		this.eng = scan.nextInt();
	}
	
	public void PrintInfo() {
		avg = (kor + eng) / 2;
		
		System.out.println("학생이름 : " + this.name);
		System.out.println("국어성적 : " + this.kor);
		System.out.println("영어성적 : " + this.eng);
		System.out.println("평균 : " + this.avg);
	}
}
