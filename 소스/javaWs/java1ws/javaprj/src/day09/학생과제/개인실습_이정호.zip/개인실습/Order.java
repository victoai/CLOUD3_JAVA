package 개인실습;

public class Order {
	private String number;
	private String id;
	private String day;
	private String name;
	private String product;
	private String address;
	
	public void Input() {
		this.number = "201803120001";
		this.id = "abc123";
		this.day = "2018년 3월 12일";
		this.name = "홍길순";
		this.product = "😛D0345-12";
		this.address = "서울시 영등포구 여의도동 20번지";
	}
	
	public void PrintInfo() {
		System.out.println("주문번호 : " + this.number);
		System.out.println("주문자아이디 : " + this.id);
		System.out.println("주문날짜 : " + this.day);
		System.out.println("주문자이름 : " + this.name);
		System.out.println("주문상품번호 : " + this.product);
		System.out.println("배송주소 : " + this.address);
	}
}
