package 개인실습;

public class Human {
	private int age;
	private String name;
	private boolean isMarried;
	private int childs;
	
	public void Input(int age, String name, boolean isMarried, int childs) {
		this.age = age;
		this.name = name;
		this.isMarried = isMarried;
		this.childs = childs;
	}
	
	public void PrintInfo() {
		System.out.println("나이 : " + this.age + "살");
		System.out.println("이름 : " + this.name);
		if(this.isMarried) {
			System.out.println("결혼 여부 : 기혼");
		}else {
			System.out.println("결혼 여부 : 미혼");
		}
		System.out.println("자녀수 : " + this.childs + "명");
	}
}
