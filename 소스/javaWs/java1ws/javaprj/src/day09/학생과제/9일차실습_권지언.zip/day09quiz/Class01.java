package day09quiz;

public class Class01 {

	String name;
	int age;
	boolean ismarried;
	int kidcnt;

	public void input() {
		this.name = "james";
		this.age = 40;
		this.ismarried = true;
		this.kidcnt = 3;
	}
	
	public void judge() {
		if(this.ismarried == true) {
			System.out.println("이 사람의 결혼 여부 : 참");
		}
		else {
			System.out.println("이 사람의 결혼 여부 : 거짓");
		}
	}

	public void print() {
		System.out.println("이 사람의 이름 : "+this.name);
		System.out.println("이 사람의 나이 : "+this.age);
		judge();
		System.out.println("이 사람의 자녀서 : "+this.kidcnt);
	}

}
