package day09quiz;

import java.util.Scanner;

public class Class03 {

	String name;
	int kor;
	int eng;
	int total;
	double avg;

	public void input(Scanner sc) {
		System.out.println("학생이름을 입력하세요");
		this.name = sc.next();
		System.out.println("국어성적을 입력하세요");
		this.kor = sc.nextInt();
		System.out.println("영어성적을 입력하세요");
		this.eng = sc.nextInt();
	}

	public void calc() {
		this.total = this.kor + this.eng;
		this.avg = this.total / 2;
	}

	public void print() {
		System.out.println("학생이름 : " + this.name);
		System.out.println("국어점수 : " + this.kor+"점");
		System.out.println("영어점수 : " + this.eng+"점");
		System.out.println("총점 : " + this.total+"점");
		System.out.println("평균 : " + this.avg+"점");
	}
}
