package day09quiz;

public class quiz02 {

	public static void main(String[] args) {

		Class02 c = new Class02();
		
		c.input();
		c.print();
		
	}

}
