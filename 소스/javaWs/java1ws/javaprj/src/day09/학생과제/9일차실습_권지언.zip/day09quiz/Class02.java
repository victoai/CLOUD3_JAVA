package day09quiz;

public class Class02 {

	String ordernum;
	String id;
	String date;
	String name;
	String pronum;
	String address;

	public void input() {
		this.ordernum = "201803120001";
		this.id = "abc123";
		this.date = "2018년 3월 12일";
		this.name = "홍길순";
		this.pronum = "D0345-12";
		this.address = "서울시 영등포구 여의도동 20번지";
	}

	public void print() {
		System.out.println("주문번호 : "+this.ordernum);
		System.out.println("주문자아이디 : "+this.id);
		System.out.println("주문날짜 : "+this.date);
		System.out.println("주문자이름 : "+this.name);
		System.out.println("주문상품번호 : "+this.pronum);
		System.out.println("배송주소 : "+this.address);
	}
}
