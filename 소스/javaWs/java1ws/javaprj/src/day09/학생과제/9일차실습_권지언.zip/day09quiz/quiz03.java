package day09quiz;

import java.util.Scanner;

public class quiz03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Class03 c = new Class03();

		c.input(sc);
		c.calc();
		c.print();

	}

}
