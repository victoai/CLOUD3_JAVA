package day09quiz;

public class quiz01 {

	public static void main(String[] args) {
		
		Class01 c = new Class01();
		
		c.input();
		c.print();
		
	}

}
