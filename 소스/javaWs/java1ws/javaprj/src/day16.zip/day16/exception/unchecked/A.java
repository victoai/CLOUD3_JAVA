package day16.exception.unchecked;

public class A {

	
	public void 놀기() {
		System.out.println("놀기");
	}
}
