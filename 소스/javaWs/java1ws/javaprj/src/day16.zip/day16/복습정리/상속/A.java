package day16.복습정리.상속;

public class A {
	
	void 놀기() {
		System.out.println("놀기");
	}

}
