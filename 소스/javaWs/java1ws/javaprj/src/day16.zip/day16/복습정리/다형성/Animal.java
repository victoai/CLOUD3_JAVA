package day16.복습정리.다형성;


public class Animal {
	void 짖다() {
		
	}

}
