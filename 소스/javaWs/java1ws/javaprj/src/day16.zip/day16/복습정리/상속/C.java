package day16.복습정리.상속;

public class C {
	int x=1;   //명시적 초기화  원하는 값으로 초기화함 
	int y=2;
	
	
	void c매서드() {
		System.out.println("c매서드");
	}

}
