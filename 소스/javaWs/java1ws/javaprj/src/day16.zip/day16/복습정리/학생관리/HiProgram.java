package day16.복습정리.학생관리;

public class HiProgram {
	
	
	public void 인사하기() {
		System.out.println(" hi");
	}

	public static void main(String[] args) {


		HiProgram  p= new HiProgram();
		p.인사하기();
		

	}

}
