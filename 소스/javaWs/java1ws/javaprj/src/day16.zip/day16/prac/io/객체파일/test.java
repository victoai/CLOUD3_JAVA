package day16.prac.io.객체파일;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
