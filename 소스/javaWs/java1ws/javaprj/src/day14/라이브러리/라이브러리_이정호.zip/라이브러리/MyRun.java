package day14.라이브러리;

public interface MyRun {
	public void run();
}
