package day14.라이브러리;

public class Main {

	public static void main(String[] args) {
		MyLib1 lib = new MyLib1();
		
//		lib.gogodan(new LJH());
		
		lib.gogodan(new MyRun() {

			@Override
			public void run() {
				for(int i = 2; i < 10; i++) {
					System.out.println(i + "단");
					System.out.println();
					for(int j = 1; j < 10; j++) {
						System.out.println(i + " X " + j + " = " + i * j);
					}
				}
				
			}
		});

	}

}
