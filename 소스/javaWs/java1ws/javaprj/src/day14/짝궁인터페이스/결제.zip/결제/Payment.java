package 결제;

import java.util.ArrayList;

public interface Payment {
	
	 public void paymentMethod(int totalSum);
	

}
