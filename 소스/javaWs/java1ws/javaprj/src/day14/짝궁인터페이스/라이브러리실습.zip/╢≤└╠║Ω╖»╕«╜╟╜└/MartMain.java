package day15.라이브러리실습;

public class MartMain {
	public static void main(String[] args) {
		MartLib lib = new MartLib();
		
		lib.run();
	}
}
