package day14.인터페이스실습;

public interface Calculator {
	
	int add( int su1, int su2);
	int sub( int su1, int su2);
	

}
