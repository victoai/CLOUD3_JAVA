package day14.인터페이스실습;

public class Momstouch implements Calculator{

	@Override
	public int add(int su1, int su2) {
		System.out.println("맘스터치 칼로리총합: ");
		return su1+su2;
	}

	@Override
	public int sub(int su1, int su2) {
		System.out.println("맘스터치 칼로리차이: ");
		return su1-su2;
	}

}
