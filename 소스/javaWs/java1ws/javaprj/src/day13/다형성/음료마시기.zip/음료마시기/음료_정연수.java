package day13.다형성.음료마시기;

public class 음료_정연수 extends AcornStudent{

	@Override
	public void 음료마시기() {
		System.out.println("정연수는 아이스티가 먹고싶습니다");
	}
}
