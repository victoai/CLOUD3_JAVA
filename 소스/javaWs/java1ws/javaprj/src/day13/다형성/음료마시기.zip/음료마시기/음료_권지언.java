package day13.다형성.음료마시기;

public class 음료_권지언 extends AcornStudent {
	@Override
	public void 음료마시기() {
		System.out.println("초코");
	}
}
