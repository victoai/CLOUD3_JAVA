package day13.다형성.음료마시기;


public class Americano extends  AcornStudent{
    @Override
    public void 음료마시기() {
        System.out.println("아메리카노");
    }

}