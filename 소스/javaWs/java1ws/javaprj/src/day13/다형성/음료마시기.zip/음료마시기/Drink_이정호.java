package day13.다형성.음료마시기;

public class Drink_이정호 extends AcornStudent {
	@Override
	public void 음료마시기() {
		System.out.println("정호는 초코를 마십니다.");
	}
}
