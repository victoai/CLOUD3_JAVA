package day09.학생성적;


/*
 * 학생정보를 처리할 type이 필요해   -> type을 만들어서 사용( 사용자정의 자료형)
 * 
 * 학생정보를 처리할  type을 설계, 정의하는 것 
 * 
 */
public class Student {

	String name;
	int kor;
	int eng;
	int total;
	 
	
}
