package day09;

public class 레시피_출력하기 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		food recipe = new food();
		recipe.음식정하기();
		recipe.음식만들기();
		
		
	}

}
