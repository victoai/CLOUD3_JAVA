package day09.캡슐화하기;

public class FruitPrint2 {

	public static void main(String[] args) {
		
		Fruit2 f = new Fruit2();
		f.fruit();
		f.printFruit();
	}

}
