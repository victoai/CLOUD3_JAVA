package day09.캡슐화하기;

public class 변수함수출력 {

	public static void main(String[] args) {
		
		변수함수 test = new 변수함수();
		
		test.영화정보입력();
		test.영화정보출력();

	}

}
