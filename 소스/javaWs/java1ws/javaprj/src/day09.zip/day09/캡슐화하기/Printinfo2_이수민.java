package day09.캡슐화하기;

public class Printinfo2_이수민 {

	public static void main(String[] args) {
		
		Product2_이수민 p = new Product2_이수민();
		
		p.setProduct();
		p.printProduct();
	
	}
}
