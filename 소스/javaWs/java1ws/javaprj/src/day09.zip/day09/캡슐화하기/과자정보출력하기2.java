package day08_2025_02_25;

public class 과자정보출력하기2 {

	public static void main(String[] args) {
		
		Snack2 obj = new Snack2();
		
		obj.InfoSnack();
		obj.printSnack();
	}
}