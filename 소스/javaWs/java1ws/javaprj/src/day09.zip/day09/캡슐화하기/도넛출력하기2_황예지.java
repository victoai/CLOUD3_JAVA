package day09.캡슐화하기;

public class 도넛출력하기2_황예지 {

	public static void main(String[] args) {
		
		donuts2 d = new donuts2();

		d.입력();
		d.출력();
		
	}

}
