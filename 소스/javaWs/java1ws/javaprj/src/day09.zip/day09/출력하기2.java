package day09;

public class 출력하기2 {

	public static void main(String[] args) {
		 
		
		data2 d = new data2();		
		d.입력하기();	   //   입력하기( d);	   매서드 호출할 때  생성된 데이터   정보가 전달된다 
		
	}

}
