package day09.클래스샘플;

public class SingerTest {

	public static void main(String[] args) {
		
		Singer TheWeeknd = new Singer(); 
		
		TheWeeknd.input("TheWeeknd", "DawnFM", 20220107 , "Out of Time", "★★★★★");
		TheWeeknd.printInfo();
		TheWeeknd.input("TheWeeknd2", "DawnFM2", 20220107 , "Out of Time2", "★★★★★");
		TheWeeknd.printInfo();
		
		 
		 
	}

}
