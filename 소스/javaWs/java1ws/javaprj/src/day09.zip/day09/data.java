package day09;

public class data {
	
	String  name;
	
	//String a;
	int b;
	double c;
	//속성 추가 
	int d;
	
	
}
