package day09;

public class object {
	int id;
	String name;
	int count;
	int price;
	
	
}
