package day09;

public class 정보출력해보기2 {

	public static void main(String[] args) {
		 
		
		object2  obj = new object2();
		
		
		obj.setObject();  //   ( setObject( obj) )   =>  object2형의 this라는 참조형변수가 이 정보를 저장한다
		obj.printObject(); //  // printObject( obj)   =>      " 
		

	}

}
