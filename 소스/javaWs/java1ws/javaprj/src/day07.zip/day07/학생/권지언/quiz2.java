package day07.학생.권지언;

public class quiz2 {

	public static void main(String[] args) {

		printstar();
		
	}

	public static void printstar() {
		for(int i=0; i<3; i++) {
			System.out.print("★");
		}
	}
}
