package day07.학생;

public class 문제3_오윤석 {

	public static void main(String[] args) {

		star1();
		star2();

	}

	public static void star1() {
		System.out.println("★★★");
	}
	
	public static void star2() {
		for (int i=0; i<3; i++) {
			System.out.print("★");
		}
		
	}

}
