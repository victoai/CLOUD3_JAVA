package day07;

public class 설음식만들기 {

	public static void main(String[] args) {
		
		
		
		//만두만들기
		String 음식1;
		System.out.println("만두만들기1");
		System.out.println("만두만들기2");
		System.out.println("만두만들기3");
		System.out.println("만두만들기4");	
		
		음식1 ="김치만두";
		
		//떡국만들기
		String 음식2;
		System.out.println("떡국 만들기1");
		System.out.println(음식1 +"넣는다");
		
		음식2 ="떡국";
		
		
		//전만들기
		String 음식3;
		System.out.println("전 만들기1");
		System.out.println("전 만들기2");
		System.out.println("전 만들기3");
		System.out.println("전 만들기4");
		음식3 ="산적";
		
		//갈비찜만들기 
		
		String 음식4;
		System.out.println("갈비찜 만들기1");
		System.out.println("갈비찜 만들기2");
		System.out.println("갈비찜 만들기3");
		System.out.println("갈비찜 만들기4");
		System.out.println("갈비찜 만들기5");
		
		음식4= "소갈비찜";
		//상차리기
		
		
		
		System.out.println("*****설날 상차리기 완료 ****");
		System.out.println( 음식1 + 음식2 + 음식3 + 음식4) ;
		
		
		
		

	}

}
