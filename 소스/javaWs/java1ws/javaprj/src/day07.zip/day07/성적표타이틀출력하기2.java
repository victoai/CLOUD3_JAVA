package day07;

public class 성적표타이틀출력하기2 {

	
	public static void main(String[] args) { 
		
		printTitle();    //함수호출 (함수는 호출해야 실행됨, 반드시 돌아옴)
		
		printTitle(); 
		
	 
		printTitle();		
		 
	}
	
	
	
	
	// 성적표 출력하기 기능( 함수 만들기) 
	// 반환type  함수명 ( 매개변수 )
	
	public static  void  printTitle() {
		System.out.println("====================");
		System.out.println("========성적표========");
		System.out.println("===================="); 
	
	}
	
	

}
