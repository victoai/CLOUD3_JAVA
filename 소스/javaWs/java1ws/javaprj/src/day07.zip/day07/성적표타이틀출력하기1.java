package day07;

public class 성적표타이틀출력하기1 {

	public static void main(String[] args) {
		
		/* 성적표*/
		System.out.println("====================");
		System.out.println("========성적표========");
		System.out.println("====================");
		
		
		
		
		/* 성적표*/
		
		System.out.println("====================");
		System.out.println("========성적표========");
		System.out.println("====================");
		
		
		
		

		/* 성적표*/
		
		System.out.println("====================");
		System.out.println("========성적표========");
		System.out.println("====================");
		
		
		
		// 1. 성적표타이틀 출력하는 코드 작성 , 필요하면 복사를 해서 사용하는 방법 
		// => 코드 중복의 발생  (코드량 증가 , 코드 유지보수 하기 어려워 짐 )
		
		
		 
	}

}
