package day07;

public class 값증가하기 {

	public static void main(String[] args) {
		
		
		 int index=0;
		 index++;
		 index++;
		 
		 
		 System.out.println( index);

	}

}
