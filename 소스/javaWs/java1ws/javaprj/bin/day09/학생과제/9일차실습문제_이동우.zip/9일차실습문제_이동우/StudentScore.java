package day09.연습;

public class StudentScore {

	
	private String name;
	private int kor;
	private int eng;
	private int avg;
	
	
	public void input(String name, int kor, int eng) {
		this.name = name;
		this.kor = kor;
		this.eng = eng;
	}
	
	public void calc(int avg) {
		this.avg = (this.kor + this.eng) / 2;
	}
	
	public void getInfo() {
		System.out.println(this.name);
		System.out.println(this.kor);
		System.out.println(this.eng);
		System.out.println(this.avg);
	}
}
