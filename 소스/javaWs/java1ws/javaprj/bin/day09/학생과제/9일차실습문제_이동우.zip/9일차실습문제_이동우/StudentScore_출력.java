package day09.연습;

public class StudentScore_출력 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		StudentScore s = new StudentScore();
		
		s.input("홍길동", 90 , 80);
		s.calc(0);
		s.getInfo();
		
		
	}

}
