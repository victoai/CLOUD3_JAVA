package day09.연습;

public class Shopping {

	//long은 기본적으로 int로 생각하기 때문에 int의 범위를 넘어가게 되면 숫자 뒤에 L을 붙여줘야 한다
	long num; 
	String id;
	String day;
	String name;
	String orderNum;
	String address;
	
	public void input(long num, String id, String day,String name, String orderNum, String address) {
		
		this.num = num;
		this.id = id;
		this.day = day;
		this.name = name;
		this.orderNum = orderNum;
		this.address = address;
	}
	
	public void getInfo() {
		System.out.println(this.num);
		System.out.println(this.id);
		System.out.println(this.day);
		System.out.println(this.name);
		System.out.println(this.orderNum);
		System.out.println(this.address);
	}
}
