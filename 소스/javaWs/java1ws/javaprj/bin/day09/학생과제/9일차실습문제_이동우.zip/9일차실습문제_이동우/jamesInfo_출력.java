package day09.연습;

public class jamesInfo_출력 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JamesInfo j = new JamesInfo();
		
		j.input(40, "james", true, 3);
		j.getInfo();
		
	}

}
