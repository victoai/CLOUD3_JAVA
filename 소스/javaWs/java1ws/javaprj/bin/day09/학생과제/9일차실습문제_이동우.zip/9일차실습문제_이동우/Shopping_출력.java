package day09.연습;

public class Shopping_출력 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Shopping s = new Shopping();
		
		s.input(201803120001L, "abc123", "2018년3월12일", "홍길순", "D0345-12", "서울시 영등포구 여의도동 20번지");
		s.getInfo();
	}

}
