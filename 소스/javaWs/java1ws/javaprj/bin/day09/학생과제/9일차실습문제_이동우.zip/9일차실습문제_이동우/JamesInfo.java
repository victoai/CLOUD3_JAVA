package day09.연습;

public class JamesInfo {

	
	int age;
	String name;
	boolean marry;
	int child;
	
	
	public void input(int age, String name, boolean marry, int child) {
		this.age = age;
		this.name = name;
		this.marry = marry;
		this.child = child;
	}
	
	public void getInfo() {
		System.out.println(this.age);
		System.out.println(this.name);
		if(marry == true) {
			System.out.println("결혼하였습니다.");
		}else {
			System.out.println("결혼하지 않았습니다.");
		}
		System.out.println(this.child);
	}
}
