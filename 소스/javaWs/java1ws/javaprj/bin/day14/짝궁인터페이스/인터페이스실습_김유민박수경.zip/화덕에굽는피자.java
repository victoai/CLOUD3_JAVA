package day14_0306_인터페이스실습1;

public interface 화덕에굽는피자 {
	
	 public void 화덕에굽기();
	 
}
