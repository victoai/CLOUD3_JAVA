package day14_0306_인터페이스실습1;

public interface OrderInfo {
	
	String topping(String topping1, String topping2);
	String side(String side1, String side2);
	}

