package day14_0306_인터페이스실습1;

public class 프렌치화이트피자 implements 오븐에굽는피자{

	@Override
	public void 오픈에굽기() {
		
		System.out.println("프렌치화이트 피자");
		
	}

}
