package day14_0306_인터페이스실습1;

public class 퀴트로 implements 화덕에굽는피자{

	@Override
	public void 화덕에굽기() {
		
		System.out.println("퀴트로 피자");
		
	}
	
}
