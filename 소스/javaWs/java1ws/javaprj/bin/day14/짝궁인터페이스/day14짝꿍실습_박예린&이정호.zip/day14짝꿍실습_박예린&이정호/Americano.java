package day14.카페실습;

public class Americano implements Menu
{
	@Override
	public String name() {
		return "아메리카노";
		
	}

	@Override
	public int price() {
		return 4500;
		
	}

	@Override
	public int totalPrice(int count) {
		return count * 4500;
	}
	
}