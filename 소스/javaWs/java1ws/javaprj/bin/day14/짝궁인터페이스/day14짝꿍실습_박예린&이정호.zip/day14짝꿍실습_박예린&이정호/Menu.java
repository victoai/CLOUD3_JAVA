package day14.카페실습;

public interface Menu
{
	public String name();
	public int price();
	public int totalPrice(int count);
}