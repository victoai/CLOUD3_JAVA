package day14.카페실습;

public class Mocha implements Menu
{

	@Override
	public String name() {
		return "카페모카";
		
	}

	@Override
	public int price() {
		return 5500;
		
	}

	@Override
	public int totalPrice(int count) {
		return count * 5500;
	}
}