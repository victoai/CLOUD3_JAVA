package day08;

public class Book {
	String book_name;
	String author;
	int price;
}
