package day15.정렬.myarrays;

public interface MyComparable {
	
	public int compareTo( Object another);   // 기준이 크면 양수, 기준이 작으면음수 반환 
	

}
