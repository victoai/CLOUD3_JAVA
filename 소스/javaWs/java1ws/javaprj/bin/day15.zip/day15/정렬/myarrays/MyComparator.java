package day15.정렬.myarrays;

public interface MyComparator {
	
	public int compare( Object o1, Object o2);   // 기준, 비고  기준이 크면 양수, 기준이 작으면 음수 

}
