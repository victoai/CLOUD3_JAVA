package day14.라이브러리;

public class OYS implements MyRun {

	@Override
	public void run() {
		System.out.println("=============");

		for (int i = 1; i <= 2; i++) {
			System.out.println("∥     ∥     ∥");
			System.out.println("∥     ∥     ∥");
			System.out.println("=============");
		}
	}

}
