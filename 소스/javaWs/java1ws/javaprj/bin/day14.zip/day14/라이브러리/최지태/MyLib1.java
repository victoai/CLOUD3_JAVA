package day14.라이브러리.최지태;

import java.util.Arrays;

public class MyLib1 {
	public void 정수형오름차순정렬출력(정렬하기 code) {
		System.out.println(Arrays.toString(code.오름차순정렬()));
	}
	
	public void 정수형내림차순정렬출력(정렬하기 code) {
		System.out.println(Arrays.toString(code.내림차순정렬()));
	}
}
