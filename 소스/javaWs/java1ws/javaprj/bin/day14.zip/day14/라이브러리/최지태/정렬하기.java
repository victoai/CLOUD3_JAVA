package day14.라이브러리.최지태;

public interface 정렬하기 {
	public int[] 오름차순정렬();
	
	public int[] 내림차순정렬();
}
