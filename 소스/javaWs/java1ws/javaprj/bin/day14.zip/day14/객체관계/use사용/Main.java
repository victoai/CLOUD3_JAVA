package day14.객체관계.use사용;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a= new A();
		
		
		//a.A매서드( new B());
		
		
		B b = new B();
		a.A매서드(b);
		

	}

}
