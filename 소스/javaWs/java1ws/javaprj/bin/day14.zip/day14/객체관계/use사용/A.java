package day14.객체관계.use사용;

public class A {

	
	//
	
	public void A매서드(  B b) {
		
		System.out.println("A매서드");
		b.B매서드();
		
	}
}
