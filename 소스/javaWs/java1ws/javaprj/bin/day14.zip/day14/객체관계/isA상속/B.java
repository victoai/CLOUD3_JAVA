package day14.객체관계.isA상속;

public class B extends A{

	
	public void B매서드() {
		System.out.println("B매서드");
	}
}
