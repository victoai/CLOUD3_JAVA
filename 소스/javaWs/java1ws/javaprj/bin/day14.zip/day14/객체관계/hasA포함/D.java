package day14.객체관계.hasA포함;

public class D {
	
	
	public void D매서드() {
		System.out.println("d매서드");
	}

}
