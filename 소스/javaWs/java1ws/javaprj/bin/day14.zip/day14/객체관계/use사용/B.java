package day14.객체관계.use사용;

public class B {

	
	public void B매서드() {
		System.out.println("b매서드");
	}
}
