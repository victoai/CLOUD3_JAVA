package day14.인터페이스;

public class 박예린 implements 싸움이가능한17대1, 장풍이가능한
{
	public void 싸움하기()
	{
		System.out.println("헉! 17대 1로 싸운다!");
		System.out.println("물론 이쪽이 17이다.");
	}
	
	public void 장풍날리기()
	{
		System.out.println("장풍을 날려야 한다!");
		System.out.println("선풍기를 가져와서 틀었다.");
		System.out.println("상대의 가발이 날아간다!");
	}
}
