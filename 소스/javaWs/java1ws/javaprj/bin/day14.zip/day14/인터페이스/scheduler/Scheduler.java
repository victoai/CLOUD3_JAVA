package day14.인터페이스.scheduler;

public interface Scheduler {
	public void getNextCall();
    public void sendCallToAgent();


}
