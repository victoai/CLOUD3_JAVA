package day14.인터페이스;

public class 최하은 implements 불어가능한, 나는게가능한{
	
		@Override
		public void 불어를한다() {
			System.out.println("봉쥬르");
		}

		@Override
		public void 날수있다() {
			
			System.out.println("오예높은하늘");
			
		}
	}

