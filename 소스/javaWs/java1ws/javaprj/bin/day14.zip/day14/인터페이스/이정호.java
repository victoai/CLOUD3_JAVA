package day14.인터페이스;

public class 이정호 implements 나는게가능한, 장풍이가능한 {

	@Override
	public void 날수있다() {
		System.out.println("날개를 활짝 펼고 세상을 자유롭게 날꺼야!");
		
	}

	@Override
	public void 장풍날리기() {
		System.out.println("빵야! 빵야! 빵! 빠아앙야!!!");
		
	}

}
