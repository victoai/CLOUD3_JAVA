package day14.인터페이스;

public class 정연수 implements 많이먹는게가능한{

	@Override
	public void 많이먹다() {


		System.out.println("100인분 식사완료");
		
	}
	
	

}
