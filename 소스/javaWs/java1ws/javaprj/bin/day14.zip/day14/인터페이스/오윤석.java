package day14.인터페이스;

public class 오윤석 implements 많이먹는게가능한, 변신가능한 {

	@Override
	public void 많이먹다() {
		System.out.println("치킨한마리");
	}

	@Override
	public void 변신하기() {
		System.out.println("변신한다");
	}

}
