package day14.인터페이스;

public interface 싸움이가능한17대1 {
	   public void  싸움하기();

}
