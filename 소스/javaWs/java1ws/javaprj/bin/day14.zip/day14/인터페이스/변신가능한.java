package day14.인터페이스;

public interface 변신가능한 {
	public void 변신하기();

}
