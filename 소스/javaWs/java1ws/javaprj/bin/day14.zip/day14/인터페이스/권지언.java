package day14.인터페이스;

public   class 권지언 implements 장풍이가능한, 태권도가가능한 {
	@Override
	public void 장풍날리기() {
		System.out.println("아도겐");
	}

	@Override
	public void 태권도하기() {
		System.out.println("격파하기");
	}
}
