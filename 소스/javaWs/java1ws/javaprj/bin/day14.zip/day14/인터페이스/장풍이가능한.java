package day14.인터페이스;

public interface 장풍이가능한 {

	 public void  장풍날리기();

}
