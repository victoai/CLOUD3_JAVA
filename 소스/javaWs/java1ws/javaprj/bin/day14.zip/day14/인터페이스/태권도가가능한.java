package day14.인터페이스;

public interface 태권도가가능한 {
	  public void  태권도하기();

}
