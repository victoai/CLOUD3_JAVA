package day14.인터페이스;

public class WJY   implements  많이먹는게가능한  , 나는게가능한{

	@Override
	public void 많이먹다() {
		System.out.println("사과10개");
		
	}

	@Override
	public void 날수있다() {
		System.out.println("야호 ~날개를 펴고 난다 ");
		
	}

}
