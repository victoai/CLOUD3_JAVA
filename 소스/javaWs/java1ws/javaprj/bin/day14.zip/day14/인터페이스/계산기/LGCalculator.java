package day14.인터페이스.계산기;

public class LGCalculator {
	public int addLG( int su1, int su2) {
		
		return su1+su2;
	}
	
	
	public int subLG( int su1, int su2) {
		return su1-su2;
	}
	
}
