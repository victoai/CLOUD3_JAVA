package day14.인터페이스;

public class 김유민 implements 많이먹는게가능한 , 나는게가능한{
	
	@Override
	public void 많이먹다() {
		System.out.println("피자 한 판 먹기");
	}

	@Override
	public void 날수있다() {
		System.out.println("꿈속에서 자주 날아다닌다");
	}

}
