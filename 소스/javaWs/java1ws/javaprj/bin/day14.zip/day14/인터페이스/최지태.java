package day14.인터페이스;

public class 최지태 implements 불어가능한, 태권도가가능한 {
	@Override
	public void 불어를한다() {
		System.out.println("봉쥬르 본 주흐네");
	}
	
	@Override
	public void 태권도하기() {
		System.out.println("태권도");	
	}
}
