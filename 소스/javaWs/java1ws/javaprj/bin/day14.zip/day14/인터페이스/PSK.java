package day14.인터페이스;

public class PSK implements 불어가능한{


	@Override
	public void 불어를한다() {
		System.out.println("Salut tout le monde");
		
	}


}
