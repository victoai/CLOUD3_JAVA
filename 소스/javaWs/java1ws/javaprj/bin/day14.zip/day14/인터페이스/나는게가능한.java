package day14.인터페이스;

public interface 나는게가능한 {
	 public  void 날수있다();

}
