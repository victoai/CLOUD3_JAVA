package day14.인터페이스;

public class 이수민 implements 싸움이가능한17대1, 나는게가능한 {

	@Override
	public void 싸움하기() {
		// TODO Auto-generated method stub
		System.out.println("저는 17대1 싸움에서 17쪽에 서고싶습니다^^");
	}

	@Override
	public void 날수있다() {
		// TODO Auto-generated method stub
		System.out.println("집에날아가다... 날아가기..... 와아..");
	}

	
}
