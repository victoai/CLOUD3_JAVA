package day14.인터페이스.계산기;

public class SMCalculator {
	
	public int addSM( int su1, int su2) {
	
		return su1+su2;
	}
	
	
	public int subSM( int su1, int su2) {
		return su1-su2;
	}
	

}
