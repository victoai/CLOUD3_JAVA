package day14.인터페이스;

public class 이동우 implements 변신가능한, 장풍이가능한 {

	@Override
	public void 장풍날리기() {
		System.out.println("손에 기를 모아 힘껏 날리기~~!!~~");
		
	}

	@Override
	public void 변신하기() {
		System.out.println("모래요정 바람돌이 : 카피 카피 룸룸 카피 카피 룸룸");
		
	}

	
	
}
