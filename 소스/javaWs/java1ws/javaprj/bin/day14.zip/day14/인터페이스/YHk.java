package day14.인터페이스;

public class YHk implements 많이먹는게가능한,나는게가능한 {

    @Override
    public void 많이먹다() {
        System.out.println("많이먹다");
    }

    @Override
    public void 날수있다() {
        System.out.println("날수 있다");
    }
}
