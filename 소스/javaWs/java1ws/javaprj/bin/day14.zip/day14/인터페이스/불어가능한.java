package day14.인터페이스;

public interface 불어가능한 {
	 public void  불어를한다();

}
