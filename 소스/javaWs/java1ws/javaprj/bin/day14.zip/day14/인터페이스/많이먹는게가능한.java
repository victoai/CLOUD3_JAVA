package day14.인터페이스;

public interface 많이먹는게가능한 {
	//추상매서드만 가진다
	// abstract 생략가능
	public void 많이먹다() ;

}
