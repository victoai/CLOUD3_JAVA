package day14.짝궁인터페이스.박예린_이정호;

public interface Menu
{
	public String name();
	public int price();
	public int totalPrice(int count);
}