package day14.핸드폰;

public interface Battery {	
	public void getEnergy();
}
