package day12_상속_inheritance연습;

public class Bicycle extends Vehicle{

	
	public void 두발() {
		System.out.println("인간의 두발로 얻은 동력을 이용하여 나아간다 ");
	}
	public void 자전거도로() {
		System.out.println("자전거 도로위를 달린다 ");
	}
	
	
}
