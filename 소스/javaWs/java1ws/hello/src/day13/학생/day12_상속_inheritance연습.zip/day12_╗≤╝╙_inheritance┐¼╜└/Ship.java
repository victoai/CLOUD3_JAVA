package day12_상속_inheritance연습;

public class Ship extends Vehicle{
	public void 바다() {
		System.out.println("배는 바다에서 이동하는 수단이다");
	}

	@Override
	public void 바퀴() {
		//super.바퀴();
		System.out.println(" 바퀴가 필요 없는걸요?");
	}
}
