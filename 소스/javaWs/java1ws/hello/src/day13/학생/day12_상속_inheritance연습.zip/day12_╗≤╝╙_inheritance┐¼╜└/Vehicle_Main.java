package day12_상속_inheritance연습;

public class Vehicle_Main {

	public static void main(String[] args) {

		//
		System.out.println("  <<이동수단 1. 자전거>>");
		Bicycle b = new Bicycle();
		b.두발();
		b.좌석();
		b.기능();
		//
		System.out.println("  <<이동수단 4. 자동차>>");
		Car c= new Car();
		c.면허증();
		c.좌석();
		c.기능();
		//
		System.out.println("  <<이동수단 2. 비행기>>");
		Airplane a = new Airplane();
		a.하늘();
		a.기능();		
		a.좌석();
		//
		System.out.println("  <<이동수단 3. 배>>");
		Ship s= new Ship();
		s.바다();
		s.좌석();
		s.기능();
		//
		System.out.println("  <<이동수단 5. 기차>>");
		Train t = new Train();
		t.철로();
		t.좌석();
		t.기능();
		
		//업캐스팅
				Vehicle vehicle1 =null;
				vehicle1 = c;
				
				Vehicle vehicle2 =null;
				vehicle2 = b;
				
				System.out.println();
				vehicle1.위치();
				vehicle2.위치();
				//vehicle2.자전거도로(); 는 사용불가. 해석의 도구가 축소된다.
				
			//다운캐스팅
				((Bicycle)vehicle2).자전거도로();
				
				
				
				
			//오버라이드
		System.out.println();
		System.out.println(" < 나는 누구일까요? >");
		
		Vehicle [] arr = new Vehicle[5];
		arr[0] = new Airplane();
		arr[1] = new Bicycle();
		arr[2] = new Car();
		arr[3] = new Ship();
		arr[4] = new Train();
		
		for(int i=0; i<arr.length; i++) {
			arr[i].바퀴();
			
		}		
		
		
		
		
		
		System.out.println();
		Vehicle v1 = new Ship();
		매서드(v1);
		Vehicle v2 = new Airplane();
		매서드(v2);
		
		
	}
	
	
		
	public static void 매서드(Vehicle ride) {
		ride.위치();
		
		// 어디위를 움직이는가?   
		
		if(ride instanceof Ship) {
			((Ship)ride).바다();
		}else if(ride instanceof Airplane) {
			((Airplane)ride).하늘();
		}
		
		
	}
	
	
	
}
