package day12_상속_inheritance연습;

public class Train extends Vehicle{

	public void 철로() {
		System.out.println("철로가 깔려있어야만 이동할 수 있다");
	}
	
	@Override
	public void 바퀴() {
//		super.바퀴();
		System.out.println(" 내가 제일 바퀴를 많이 가지고 있을걸요?");
	}
}
