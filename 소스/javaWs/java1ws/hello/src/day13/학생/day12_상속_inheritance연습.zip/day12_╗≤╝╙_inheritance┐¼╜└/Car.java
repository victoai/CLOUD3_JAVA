package day12_상속_inheritance연습;

public class Car extends Vehicle{

	public void 면허증() {
		System.out.println("면허증을 가지고 있는 탈것중 제일 많은 사람이 가지고있다");
	}
	
	
	@Override
	public void 바퀴() {
//		super.바퀴();
		System.out.println(" 나는 바퀴가 4개입니다");
		
	}
	
}
