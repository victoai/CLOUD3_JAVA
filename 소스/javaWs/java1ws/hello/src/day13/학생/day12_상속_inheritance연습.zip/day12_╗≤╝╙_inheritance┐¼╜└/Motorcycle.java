package day12_상속_inheritance연습;

public class Motorcycle extends Vehicle{

	public void 배달() {
		System.out.println("배달로 제일 많이 쓰이는 탈것일것이다.. ");
	}
	
	
	
	
	
	
}
