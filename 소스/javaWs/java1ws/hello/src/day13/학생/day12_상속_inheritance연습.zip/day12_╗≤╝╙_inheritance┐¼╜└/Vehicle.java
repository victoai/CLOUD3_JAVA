package day12_상속_inheritance연습;

public class Vehicle {

	
	
	public void 기능() {
		System.out.println("인간의 이동수단이다");
	}
	
	public void 좌석() {
		System.out.println("앉을수 있는 좌석이 있다");
	}
	
	public void 바퀴() {
		System.out.println("바퀴가 있어 굴러간다 ");
		System.out.println("바퀴가 " + Wheel(2) +"개로 움직인다");
	}
	
	public int Wheel(int num) {
		return num;
	}
	
	public void 위치() {
		System.out.println("나는 땅위를 달린다");
	}
	
	
	
	
}
