package day12_상속_inheritance연습;

public class Airplane extends Vehicle {

	
	public void 하늘() {
		System.out.println("비행기는 하늘에서 이동하는 탈것이다");
	}
	
	@Override
	public void 바퀴() {
//		super.바퀴();
		System.out.println(" 난 바퀴보다 날개로 움직입니다. ");
	}
	
	
	@Override
	public void 좌석() {
		super.좌석();
		System.out.println("등급에 따라 편리함이 달라집니다. ");
	}
	
	
	
}
