package day13;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ManageSystem {
	ArrayList<Acorn> arr = new ArrayList<>();
	BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
	
	// 등록 메서드
	public void register() throws IOException {
		System.out.println("필수정보 입력");
		System.out.println("---------------------");
		System.out.print("아이디 입력 : ");
		String id = bf.readLine();
		System.out.print("이름 입력 : ");
		String name = bf.readLine();
		System.out.print("휴대폰 번호 입력 : ");
		String phoneNum = bf.readLine();
		Acorn me = new MyInfo(id, name, phoneNum);
		
		System.out.println();
		System.out.println("추가정보 입력을 원하신다면 1을 아니면 0을 입력해주세요");
		System.out.println("------------------------------------------------------");
		System.out.print(">>> ");
		if (Integer.valueOf(bf.readLine()).equals(1)) {
			System.out.println();
			
			System.out.println("추가정보 입력");
			System.out.println("---------------------");
			System.out.print("이메일 입력 : ");
			String email = bf.readLine();
			
			// instanceof 로 확인해서 맞다면 다운캐스팅을 통해 접근
			if (me instanceof MyInfo) {
				((MyInfo)me).setEmail(email);
			}
			System.out.print("학년 입력 : ");
			String grade = bf.readLine();
			if (me instanceof MyInfo) {
				((MyInfo)me).setGrade(grade);
			}
		}
		System.out.println("\n현재까지의 정보");
		System.out.println("---------------------");
		me.printInfo();
		System.out.println("\n입력하신 정보가 맞다면 1을 아니면 0을 입력해주세요");
		System.out.println("----------------------------------------------------");
		System.out.print(">>> ");
		if (Integer.valueOf(bf.readLine()).equals(1)) {
			arr.add(me);
			System.out.println();
			System.out.println("성공적으로 정보가 입력되었습니다.\n");
		} else {
			System.out.println();
			System.out.println("정보 입력이 취소되었습니다.\n");
		}
	}
	
	// 조회 메서드
	public void Inquiry() throws IOException {
		System.out.println("아이디 입력");
		System.out.print(">>> ");
		String input = bf.readLine();
		for (int i = 0; i < arr.size(); i++) {
			if (arr.get(i).getId().equals(input)) {
				print(i);
				break;
			}
			if (i == arr.size()-1) {
				System.out.println("\n일치하는 정보가 없습니다\n");
			}
		}
	}
	
	// 출력 메서드
	public void print(int index) throws IOException {
		System.out.println("\n내 정보");
		System.out.println("---------------------");
		arr.get(index).printInfo();
	}
	
	// 전체 출력 메서드
	public void printAll() throws IOException {
		System.out.println("모든 정보");
		for (Acorn i : arr) {
			System.out.println("---------------------");
			i.printInfo();
		}
		System.out.println();
	}
	
	public void exit() {
		System.out.println("종료합니다...");
	}
}
