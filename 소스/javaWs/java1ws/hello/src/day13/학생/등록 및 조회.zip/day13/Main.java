package day13;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	public static void main(String[] args) throws IOException {
		
		// 입력 형식 차이
		// 속도, 성능, 안정성 -> BufferedReader 가 scanner 보다 우세
		// 입력 유연성 -> Scanner 가 BufferedReader 보다 우세
		
		// 대용량 데이터를 다루는 알고리즘 문제를 풀 때
		// 속도와 성능을 늘리고 싶을때 유용합니다
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		
		ManageSystem system = new ManageSystem();
		
		// 입력을 받는 부분
		loop : while (true) {
			System.out.println("1. 등록 | 2. 조회 | 3. 전체조회 | 0. 종료");
			System.out.println("-----------------------------------------");
			System.out.print(">>> ");
			int select = Integer.valueOf(bf.readLine());
			
			System.out.println();
			
			switch (select) {
			case 1:
				system.register();
				break;
			case 2:
				system.Inquiry();
				break;
			case 3:
				system.printAll();
				break;
			case 0:
				system.exit();
				break loop;
			default:
				System.out.println("잘못된 입력입니다.\n");
			}
		}
	}
}
