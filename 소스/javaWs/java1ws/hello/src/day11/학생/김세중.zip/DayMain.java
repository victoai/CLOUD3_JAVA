package day11;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DayMain {
	private static Scanner sc = new Scanner(System.in);
	private static Day[] schedule = new Day[3];
	private static int currentIndex = 0;
	static LocalDate date = LocalDate.now();
	static DateTimeFormatter formmater = DateTimeFormatter.ofPattern("YYYY년 MM월 dd일");
	static String formmateDate = date.format(formmater);

	public static void main(String[] args) {

		while (true) {
			System.out.println("메뉴를 선택하세요: \n1 - 일정 추가\n2 - 일정 출력\n3 - 일정 수정\n4 - 일정 완료 변경 \n0 - 종료");

			int num = sc.nextInt();
			sc.nextLine();
			switch (num) {
			case 1:
				if (currentIndex < schedule.length) {
					addSchedule();
				} else {
					System.out.println("일정이 가득 찼습니다.");
				}
				break;
			case 2:
				printSchedule();
				break;
			case 3:
				updateSchedule();
				break;
			case 4:
				updateResult();
				break;
			case 0:
				System.out.println("프로그램을 종료합니다.");
				sc.close();
				return;
			default:
				System.out.println("잘못된 입력입니다. 다시 시도하세요.");
				break;
			}
		}
	}

	static void addSchedule() {
		System.out.println("일정 " + (currentIndex + 1) + " 입력");

		System.out.print("제목: ");
		String title = sc.nextLine();

		// System.out.print("날짜: ");
		String date = formmateDate;

		System.out.print("설명: ");
		String desc = sc.nextLine();

		System.out.print("완료 여부 (true/false or t/f): ");
		String resultInput = sc.nextLine().trim().toLowerCase();
		boolean result = resultInput.equals("true") || resultInput.equals("t");

		schedule[currentIndex] = new Day(title, date, desc, result);
		currentIndex++;
	}

	static void printSchedule() {
		System.out.println("\n일정 출력:");
		if (currentIndex == 0) {
			System.out.println("일정 존재 x");
			return;
		}
		for (int i = 0; i < currentIndex; i++) {
			System.out.println("일정" + (i + 1));
			System.out.println(schedule[i].toString());
		}
	}

	static void updateSchedule() {

		if (currentIndex == 0) {
			System.out.println("일정이 존재 x");
			return;
		}
		System.out.print("수정할 일정의 번호를 입력하세요 (1 ~ " + currentIndex + "): ");
		int index = sc.nextInt() - 1;
		sc.nextLine();

		if (index < 0 || index >= currentIndex) {
			System.out.println("유효하지 않은 일정 번호입니다.");
			return;
		}

		System.out.println("일정 " + (index + 1) + " 수정");

		System.out.print("새로운 제목: ");
		String title = sc.nextLine();

		System.out.print("새로운 날짜: ");
		String date = sc.nextLine();

		System.out.print("새로운 설명: ");
		String desc = sc.nextLine();

		System.out.print("완료 여부 (true/false or t/f): ");
		String resultInput = sc.nextLine().trim().toLowerCase();
		boolean result = resultInput.equals("true") || resultInput.equals("t");

		schedule[index].setTitle(title);
		schedule[index].setDate(date);
		schedule[index].setDesc(desc);
		schedule[index].setResult(result);
		System.out.println("일정 수정 완료.");
	}

	static void updateResult() {
		if (currentIndex == 0) {
			System.out.println("일정 존재 x");
			return;
		}

		System.out.print("완료상태를 수정할 일정의 번호를 입력하세요 (1 ~ " + currentIndex + "): ");
		int index = sc.nextInt() - 1;
		sc.nextLine();

		if (index < 0 || index >= currentIndex) {
			System.out.println("유효하지 않은 일정 번호입니다.");
			return;
		}

		boolean currentResult = schedule[index].getResult();
		schedule[index].setResult(!currentResult);
		System.out.println(index + 1 + "번의 완료상태가 " + !schedule[index].getResult() + "에서 " + schedule[index].getResult()
				+ "로 변경되었습니다.");
	}
}
