package day11;

public class Day {
	private String title;
	private String date;
	private String desc;
	private boolean result;

	Day(String title, String date, String desc, boolean result) {
		this.title = title;
		this.date = date;
		this.desc = desc;
		this.result = result;
	}

	public String getTitle() {
		return title;
	}

	public String getDate() {
		return date;
	}

	public String getDesc() {
		return desc;
	}

	public boolean getResult() {
		return result;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "제목: " + title + ", 날짜: " + date + ", 설명: " + desc + ", 완료여부: " + (result ? "완료" : "미완료") + "\n";
	}

}
