package day11.상속.상속;

public class Professor extends Researcher {
	public void 가르치기() {
		System.out.println( "가르치기");
	}

}
