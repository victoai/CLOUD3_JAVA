package day11.상속.상속미사용;

public class Student {
	
	public void 말하기() {
		System.out.println("말한다");
	}
	
	public void  먹기() {
		System.out.println( "먹기");
	}
	
	public void  걷기() {
		System.out.println(" 걷기  ver2");
	}
	
	public void 잠자기() {
		System.out.println( "잠자기");
	}
	
	
	public void 공부하기() {
		System.out.println( "공부하기");
	}
	
	

}
