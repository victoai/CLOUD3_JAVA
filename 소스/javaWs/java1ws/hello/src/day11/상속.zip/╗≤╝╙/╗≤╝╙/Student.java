package day11.상속.상속;

public class Student extends Person {
	public void 공부하기() {
		System.out.println( "공부하기");
	}

}
