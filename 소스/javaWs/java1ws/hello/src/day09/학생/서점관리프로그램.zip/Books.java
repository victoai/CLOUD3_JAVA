package day20240813;

public class Books {
	long orderNumber;
	String title;
	String author;
	String publisher;
	String date;
	int price;
	boolean possible;

	public void input(long orderNumber, String title, String author, String publisher, String date, int price,
			boolean possible) {
		this.orderNumber = orderNumber;
		this.title = title;
		this.author = author;
		this.publisher = publisher;
		this.date = date;
		this.price = price;
		this.possible = possible;
	}

	public void printInfo() {
		System.out.println("주문번호 : " + this.orderNumber);
		System.out.println("제목 : " + this.title);
		System.out.println("저자 : " + this.author);
		System.out.println("출판사 : " + this.publisher);
		System.out.println("출판일 : " + this.date);
		System.out.println("가격 : " + this.price);
		System.out.println("구매 가능 여부 : " + this.possible);
		System.out.println();
	}
	
	public static void BooksList(Books[] b) {
		for(int i=0; i<b.length; i++) {
			if(b[i]==null)  {break;}
			System.out.println((i+1)+ "." + b[i].title);
		}
	}
}
