package exam;

//import java.util.ArrayList;

public class Product {
	
	// 기본품목
	// Product products[] = new Product("새우깡", 500, 0.1);
	
	public int iSortNum;	//정렬순서
	private String strName;	//상품명
	private int iPrice;		//상품가격
	private double dbWeight;	//상품무게
	
	public Product() {
		
	}
	
	
	public Product(int _iSortNum, String _strName, int _iPrice, double _dbWeight) {
		iSortNum = _iSortNum;
		strName = _strName;
		iPrice = _iPrice;
		dbWeight = _dbWeight;
	}
	
	
////////////// 새로운 상품 등록 기능
	public void AddProduct(int _iSortNum, String _strName, int _iPrice, double _dbWeight) {
		iSortNum = _iSortNum;
		strName = _strName;
		iPrice = _iPrice;
		dbWeight = _dbWeight;
	}
	
	
	public Product[] SetSortNum(Product[] _products, int _iIndex) {
		
///////////////// 새로운 배열을 생성하여 무게순으로 정리한 iSortNum을 배열인덱스에 넣기.
		Product[] productsSort = new Product[_iIndex];
		
		return _products;
		
	}
	

	
	public void PrintProduct() {
		System.out.println(
				"(" + iSortNum + ") " + strName + "-\t" + iPrice + "원\t" + dbWeight + "Kg"
				);
	}
	
}
