package exam;

import java.util.Scanner;

public class LocalShop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner( System.in);
		
		// 기본품목
		Product products[] = new Product[5];
		products[0] = new Product(1, "새우깡", 500, 0.1);
		products[1] = new Product(2, "감자깡", 700, 0.2);
		products[2] = new Product(3, "꼬깔콘", 600, 0.22);
		products[3] = new Product(4, "초코파이", 300, 0.5);
		products[4] = new Product(5, "빼빼로", 200, 0.05);
		
		
		while(true ) {
			
			int index = 0;
			// UI
			System.out.println();
			System.out.println("-LIST------------------------------");
			for(int i=0; i<products.length; i++) {
				products[i].PrintProduct();
			}
			System.out.println("-SHOP------------------------------");
			System.out.println("1.상품등록 2.가격순정렬 3.종료");
			System.out.println("-----------------------------------");
			System.out.print("입력> ");
			
			
			int iMenuNum = sc.nextInt();
			
			switch(iMenuNum) {
			case 1:
				//입력
				System.out.print("상품이름 입력> ");
				sc.nextLine();
				String newName = sc.nextLine();
				System.out.print("상품가격 입력> ");
				int newPrice = sc.nextInt();
				System.out.print("상품중량 입력> ");
				double newWeight = sc.nextInt();
				
				int iAddIndex = products.length+1;
				
				//백업
				Product[] productsOld = new Product[products.length];
				for(int i=0; i<products.length; i++ ) {
					productsOld[i] = products[i];
				}
				
				//신규
				products = new Product[iAddIndex];
				for(int i=0; i<productsOld.length; i++) {
					products[i] = productsOld[i];
				}
				products[iAddIndex-1] = new Product();
				products[products.length-1].AddProduct(iAddIndex, newName, newPrice, newWeight);
				break;
				
			case 2:
//				for(int i=0; i<products.length; i++ ) {
//					
//				}
				break;
				
			case 3:
				System.out.println("Bye~~");
				System.exit(0);
				break;
			
			};
			
			
		}
		
		
		
		
		

	}

}
