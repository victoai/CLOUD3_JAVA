package pracClass;

import java.util.ArrayList;
import java.util.Scanner;

public class LocalShop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner( System.in);
		
		// 기본품목
	    // ArrayList를 사용하여 상품 목록을 관리
        ArrayList<Product> products = new ArrayList<>();

        // 초기 상품 등록
        products.add(new Product("새우깡", 500, 0.1));
        products.add(new Product("감자깡", 700, 0.2));
        products.add(new Product("꼬깔콘", 600, 0.22));
        products.add(new Product("초코파이", 300, 0.5));
        products.add(new Product("빼빼로", 200, 0.05));
        
        Product product = new Product("", 0, 0);
//		products[0] = new Product("새우깡", 500, 0.1);
//		products[1] = new Product("감자깡", 700, 0.2);
//		products[2] = new Product("꼬깔콘", 600, 0.22);
//		products[3] = new Product("초코파이", 300, 0.5);
//		products[4] = new Product("빼빼로", 200, 0.05);
		
		
		while(true ) {
			
			int index = 0;
			// UI
			System.out.println();
			System.out.println("-LIST------------------------------");
			for(int i=0; i<products.size(); i++) {
				products.get(i).PrintProduct(i+1);
			}
			System.out.println("-SHOP------------------------------");
			System.out.println("1.상품등록 2.정렬(상품명순) 3.정렬(무게순) 4.정렬(가격순) 5.종료");
			System.out.println("-----------------------------------");
			System.out.print("입력> ");
			
			int iMenuNum = sc.nextInt();
			sc.nextLine();
			
			switch(iMenuNum) {
            case 1:
            	
                // 상품 등록
                System.out.println("추가할 상품의 이름을 입력하세요:");
                String strPn = sc.nextLine();
                System.out.println("상품의 가격을 입력하세요:");
                int intPrice = sc.nextInt();
                System.out.println("상품의 무게를 입력하세요:");
                double doubWeight = sc.nextDouble();
                product.addProduct(products, strPn, intPrice, doubWeight);
                break;
				
			case 2:
				// 정렬(상품명순)
                product.sortByName(products);
                break;
                
			case 3:
				// 정렬(무게순)
                product.sortByWeight(products);
                break;
                
			case 4:
				// 정렬(가격순)
                product.sortByPrice(products);
                break;
                
			case 5:
				System.out.println("Bye~~");
				System.exit(0);
				break;
				
			default:
                System.out.println("잘못된 입력입니다. 다시 시도하세요.");
                break;
			};
			
			
		}
	}

}
