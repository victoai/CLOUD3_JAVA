package pracClass;

import java.util.ArrayList;
import java.util.Collections;

public class Product {
	
	// 기본품목
	// Product products[] = new Product("새우깡", 500, 0.1);
	
	
//	private int iSortNum;	//정렬순서
	private String strName;	//상품명
	private int iPrice;		//상품가격
	private double dbWeight;	//상품무게
	
	
	public Product(String _strName, int _iPrice, double _dbWeight) {
		strName = _strName;
		iPrice = _iPrice;
		dbWeight = _dbWeight;
	}
	
	
    public String getStrName() {
        return strName;
    }

    public int getIPrice() {
        return iPrice;
    }

    public double getDbWeight() {
        return dbWeight;
    }
    
	public void PrintProduct(int i) {
		
		System.out.println(
				"(" + i + ") " + strName + "-\t" + iPrice + "원\t" + dbWeight + "Kg"
				);
	}
    public void addProduct(ArrayList<Product> products, String strNewName, int intNewPrice, double doubNewWeight) {
        products.add(new Product(strNewName, intNewPrice, doubNewWeight));
        System.out.println("상품이 성공적으로 추가되었습니다.");
    }
    
    public void sortByName(ArrayList<Product> products) {
        products.sort((p1, p2) -> p1.getStrName().compareTo(p2.getStrName()));
        System.out.println("상품명이름 순으로 정렬되었습니다.");
    }
    
    public void sortByWeight(ArrayList<Product> products) {
        products.sort((p1, p2) -> Double.compare(p1.getDbWeight(), p2.getDbWeight()));
        System.out.println("상품무게 순으로 정렬되었습니다.");
    }

  
    public void sortByPrice(ArrayList<Product> products) {
        products.sort((p1, p2) -> Integer.compare(p1.getIPrice(), p2.getIPrice()));
        System.out.println("상품가격 순으로 정렬되었습니다.");
    }

}
