package day12.상속_inheritance.실습;

public class Main {

	public static void main(String[] args) {
		
		Car[] car = new Car[2];
		
		car[0] = new Engine();
		car[1] = new Engine1();
		
		for(int i=0; i<car.length; i++) {
			car[i].start(true);
			print(car[i]);
		}
		

		
		
	}

	private static void print(Car car1) {
		 if(car1 instanceof Engine) {
			 ((Engine)car1).accel();
			 ((Engine)car1).stop();
		 }else if(car1 instanceof Engine1) {
			 ((Engine1)car1).doubleAccel();
			 ((Engine1)car1).stop();
		 }
		
	}

}
