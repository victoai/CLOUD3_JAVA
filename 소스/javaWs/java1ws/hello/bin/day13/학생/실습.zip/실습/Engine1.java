package day12.상속_inheritance.실습;

public class Engine1 extends Car{

	int speed = 0;

	@Override
	public void start(boolean start) {
		// TODO Auto-generated method stub
		// super.start(start);
		if (start == true) {
			System.out.println("시동이 걸렸다 부아앙");
		}
	}

	public void doubleAccel() {

		System.out.println("스피드업");
		speed+=2;
		System.out.println(speed);

	}

	public void stop() {
		System.out.println("스피드다운");
		speed--;
		System.out.println(speed);
	}
}
