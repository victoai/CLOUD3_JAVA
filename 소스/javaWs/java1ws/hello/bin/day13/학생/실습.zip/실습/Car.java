package day12.상속_inheritance.실습;

public class Car {

	boolean start;

	public void start(boolean start) {
		if (start == true) {
			System.out.println("시동을 건다");
		}
	}
	
}
