package day21.멀티스레드예제.sample;

public class CameraThread extends Thread{
	@Override
	public void run() {
		System.out.println("**********찰칵***********");
	}
}
