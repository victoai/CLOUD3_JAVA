package day21.동기;

public class 싱글Thread {

	public static void main(String[] args) {
		
		
		for(int i=1 ;  i<=1000 ; i++) {			
			System.out.println( "하이 ^^");
		}
		
		
		
		for(int i=1 ;  i<=1000 ; i++) {			
			System.out.println( "바이 ~");
		}

	}

}
