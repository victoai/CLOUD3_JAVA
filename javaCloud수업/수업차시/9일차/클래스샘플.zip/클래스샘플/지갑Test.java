package day09;

public class 지갑Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 
			 지갑 a= new 지갑();
		
			 a.input(5, 10, 5, new String[]{ "롯데" ,"신한"});
			 a.printInfo();
			 a.물건구매하다(5000);
			 
			 a.printInfo();
	 

	}

}
