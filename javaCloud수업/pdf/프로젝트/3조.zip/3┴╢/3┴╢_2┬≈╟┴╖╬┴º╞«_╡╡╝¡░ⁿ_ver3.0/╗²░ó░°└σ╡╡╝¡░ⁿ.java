package 프로젝트2차ver2;

public class 생각공장도서관 extends 우리도서관{
	// 이름, 주소, 운영시간, 휴관일, 대여권수, 대여일수, 전화번호
	@Override
	public void 이름() {
		System.out.println(" 이     름 : 생각공장도서관");
	}

	@Override
	public void 주소() {
		System.out.println(" 주     소 : 영등포구 문래북로 105");
	}
	
	@Override
	public void 전화번호() {
		System.out.println(" 전 화 번 호 : 02-2069-1893");
	}
}
