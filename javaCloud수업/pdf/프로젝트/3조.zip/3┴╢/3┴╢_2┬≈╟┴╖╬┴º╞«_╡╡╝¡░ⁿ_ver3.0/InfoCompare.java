package 프로젝트2차ver2;

public interface InfoCompare {

	int compareTo(Object obj);
}
