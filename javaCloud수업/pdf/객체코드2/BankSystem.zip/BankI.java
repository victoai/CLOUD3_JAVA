package day12.실습;

public interface BankI {
	
	public void deposit(int Money);
	
	public void withdraw(int Money);
	
	public void overrallPrint();
	
}
