package day16.복습정리.캡슐화;

public class 생성자 {
	
	public static void main(String[] args) {
		
	}

}
