package day16.학생관리;

public class HiProgramMain {
	
 

	public static void main(String[] args) {

		System.out.println(" hi");
		 

	}

}
