package day16.io.보조;
import java.util.Scanner;

public class ScannerEx {

	public static void main(String[] args) {
	 
		
		//
		Scanner sc = new Scanner( System.in);	
		
		
		String inputLine = sc.nextLine();		
		System.out.println( inputLine);
		
		sc.close();
 
	}

}
