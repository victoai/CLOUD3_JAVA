package day16.exception.unchecked;

public class B {
	
	public void 공부하기() {
		System.out.println(" 공부하기");
	}

}
