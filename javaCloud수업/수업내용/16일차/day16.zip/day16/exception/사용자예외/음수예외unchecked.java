package day16.exception.사용자예외;

public class 음수예외unchecked extends RuntimeException {
	public 음수예외unchecked() {
		 super("음수안됨 !!");
	}
}
