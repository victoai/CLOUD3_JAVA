package day16.exception.사용자예외;

public class 음수예외checked extends Exception {
	
	public 음수예외checked() {		 
		super("음수안돼");
	}

}
