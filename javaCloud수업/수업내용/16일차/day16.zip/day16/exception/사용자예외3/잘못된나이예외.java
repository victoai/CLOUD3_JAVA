package day16.exception.사용자예외3;


//checked Exception


public class 잘못된나이예외 extends Exception {
	
	public 잘못된나이예외() {
		  super("유효하지 않은 예외");
	}

}
