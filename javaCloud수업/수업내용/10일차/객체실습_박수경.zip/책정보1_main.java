package day10_0227_학생관리;


public class 책정보1_main {

	public static void main(String[] args) {
		
		책정보1 p1=new 책정보1("아이가 없는 집","알렉스 안도릴",16200);
		책정보1 p2=new 책정보1("홀","편혜영",13500);
		책정보1 p3=new 책정보1("7년의 밤","정유정",16650);
		
		//p.printInfo();
		
		System.out.println(p1.toString());
		System.out.println();
		System.out.println(p2.toString());
		System.out.println();
		System.out.println(p3.toString());
		System.out.println();
		
		
		
		
	}

}

