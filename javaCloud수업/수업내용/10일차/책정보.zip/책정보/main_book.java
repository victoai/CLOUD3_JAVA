package 책정보;

public class main_book {

	public static void main(String args[]) {
		book[] bookList = new book[3];
		bookList b = new bookList();
		b.makeList();
		b.runMain();
	}
}
