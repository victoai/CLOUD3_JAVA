package day12.상속.다형성.실습;

public class Payment {
	
	public void pay(int Payment) {
		System.out.println(Payment + "원 결제 예정. ");
	}
	
}
