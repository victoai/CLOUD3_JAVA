package day12.다형성예제문제;
	
public class Main {
	
	public static void main(String[] args) {
		Instrument instrument = new Instrument();
		Drum drum = new Drum();
		Guitar guitar = new Guitar();
		Piano piano = new Piano();
		
		Instrument[] 악기들 = {drum, guitar, piano};
		
		System.out.println("연주 시작 ~");
		
		instrument.소리내기();
		
		for(int i = 0; i<악기들.length; i++) {
			연주(악기들[i]);
		}
		
		System.out.println("연주 끝 !");
		
	}
	
	public static void 연주(Instrument instrument) {
		instrument.소리내기();
	}

}
