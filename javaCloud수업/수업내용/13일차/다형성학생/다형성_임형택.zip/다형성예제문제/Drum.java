package day12.다형성예제문제;

public class Drum extends Instrument{
	
	@Override
	public void 소리내기() {
		System.out.println("드럼이 둥둥 소리를 낸다");
	}
	
}
