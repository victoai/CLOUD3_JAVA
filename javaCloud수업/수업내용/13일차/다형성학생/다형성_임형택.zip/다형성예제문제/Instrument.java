package day12.다형성예제문제;

public class Instrument {
	public void 소리내기() {
		System.out.println("악기가 소리를 낸다");
	}
}
