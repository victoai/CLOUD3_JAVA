package day12.다형성예제문제;

public class Piano extends Instrument{
	
	@Override
	public void 소리내기() {
		System.out.println("피아노가 딩동댕 소리를 낸다");
	}
	
}
