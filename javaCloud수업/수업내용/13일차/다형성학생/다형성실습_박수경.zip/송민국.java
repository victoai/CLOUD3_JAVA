package day12_0304_상속다형성;

public class 송민국 extends 송일국{		//상속

	@Override
	public void say() {
		System.out.println("네 둘째입니다");
	}
}
