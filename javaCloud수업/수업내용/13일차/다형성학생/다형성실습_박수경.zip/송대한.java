package day12_0304_상속다형성;

public class 송대한 extends 송일국{		//상속
	
	@Override
	public void say() {
		System.out.println("네 첫째입니다");
	}
	
}
