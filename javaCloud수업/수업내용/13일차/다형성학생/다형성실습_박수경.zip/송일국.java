package day12_0304_상속다형성;

public class 송일국 {
	public void say() {
		System.out.println("얘들아");
	}
}
