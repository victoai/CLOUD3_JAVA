package day12_상속실습;

public class Student extends School{
	
	@Override
	public void 학교() {
		System.out.println("공부하기");
	}
}
