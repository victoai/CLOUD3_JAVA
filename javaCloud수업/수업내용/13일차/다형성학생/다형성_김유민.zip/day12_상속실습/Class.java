package day12_상속실습;

public class Class extends School{
	
	@Override
	public void 학교() {
		System.out.println("교실");
	}
}
