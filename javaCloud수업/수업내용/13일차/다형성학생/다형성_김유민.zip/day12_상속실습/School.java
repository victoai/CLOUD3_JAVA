package day12_상속실습;

public class School {
	
	public void 학교() {
		System.out.println("학교");
	}
}
