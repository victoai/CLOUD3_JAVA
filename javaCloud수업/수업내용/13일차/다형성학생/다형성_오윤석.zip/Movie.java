package day13;

public class Movie extends Content {

	@Override
	public void play() {
		System.out.println("영화를 상영합니다");
	}

}
