package day13;

public class Music extends Content {

	@Override
	public void play() {
		System.out.println("음악을 재생합니다");
	}

}
