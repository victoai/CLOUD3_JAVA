package day13;

public class Radio extends Content {

	@Override
	public void play() {
		System.out.println("라디오를 청취합니다");
	}

}
