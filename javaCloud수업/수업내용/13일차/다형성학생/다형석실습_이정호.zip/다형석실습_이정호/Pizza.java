package day12.다형성실습;

public class Pizza {
	
	public void printPizza() {
		System.out.println("콤비네이션 피자(16,900원)");
		System.out.println("불고기 피자(17,900원)");
		System.out.println("치즈 피자(15,900원)");
		System.out.println("페퍼로니 피자(16,900원)");
		System.out.println("포테이토 피자(17,900원)");
	}
}
