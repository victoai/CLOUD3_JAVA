package day12.실습;

public class Animal {

	String name;
	String bark;

	public Animal() {

	}

	public Animal(String name, String bark) {
		this.name = name;
		this.bark = bark;
	}

	public String toString() {
		return name + " " + bark;
	}

	public void animal() {
		System.out.println(name + "는(은) 동물입니다");
	}

}
