package day12.실습;

public class Main {

	public static void main(String[] args) {

		Dog d = new Dog("강아지", "멍멍");
		Cat c = new Cat("고양이", "냐옹");

		d.멍멍();
		c.냐옹();
		System.out.println();

		System.out.println(d.toString());
		System.out.println(c.toString());
		System.out.println();

		// 업캐스팅
		Animal a;
		System.out.println("=====업캐스팅=====");
		a = d;
		System.out.println(a.toString());

		// 다운캐스팅
		System.out.println("====다운캐스팅=====");
		if (a instanceof Dog) {
			Dog dd = (Dog) a;
			dd.run();
		}

		System.out.println();

		System.out.println("=====업캐스팅=====");
		a = c;
		System.out.println(a.toString());

		System.out.println("====다운캐스팅=====");
		if (a instanceof Cat) {
			Cat cc = (Cat) a;
			cc.run();
		}
	}

}
