package day12.실습;

public class Dog extends Animal {

	// 기본생성자
	public Dog() {

	}

	// 생성자
	public Dog(String name, String bark) {
		this.name = name;
		this.bark = bark;
	}

	public void 멍멍() {
		System.out.println("멍멍");
	}
	
	public void run() {
		super.animal();
		System.out.println("강아지가 달립니다");
	}

}
