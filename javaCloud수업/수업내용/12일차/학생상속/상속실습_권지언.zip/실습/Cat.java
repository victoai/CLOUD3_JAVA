package day12.실습;

public class Cat extends Animal {

	// 기본생성자
	public Cat() {

	}

	// 생성자
	public Cat(String name, String bark) {
		// this.name = name;
		// this.bark = bark;
		super(name, bark);
	}

	public void 냐옹() {
		System.out.println("냐옹");
	}

	public void run() {
		super.animal();
		System.out.println("고양이가 달립니다");
	}
}
