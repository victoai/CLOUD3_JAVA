package day12실습;

public class Main {

	public static void main(String[] args) {
		
		//부모 : SpiderMan
		//자식 : Spider1, Spider2, Spider3
		
		Spider1 one = new Spider1();
		one.스파이더맨();
		one.Tobey();

		Spider2 two = new Spider2();
		two.스파이더맨();
		two.Andrew();
		
		Spider3 thr = new Spider3();
		thr.스파이더맨();
		thr.Tom();
		
		System.out.println("--------------------");
		
		//업캐스팅		
		SpiderMan s1= one;
		s1.스파이더맨();
		//s.Tobey();
		SpiderMan s2 = two;
		SpiderMan s3 = thr;
	
		//다운캐스팅
		Spider1 sm1 = (Spider1) s1;
		sm1.Tobey();
		Spider2 sm2 = (Spider2) s2;
		sm2.Andrew();
		//((Spider2) s2).Andrew();
		((Spider3) s3).Tom();
		
		
		
	}

}
