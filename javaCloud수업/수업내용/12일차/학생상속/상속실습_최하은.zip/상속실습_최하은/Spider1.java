package day12실습;

public class Spider1 extends SpiderMan{

	public void Tobey() {
		System.out.println("토비 맥과이어");
		System.out.println("❤️메리 제인 왓슨");
	}
	
}
