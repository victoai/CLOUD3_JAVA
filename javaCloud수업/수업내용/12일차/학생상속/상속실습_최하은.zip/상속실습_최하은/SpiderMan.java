package day12실습;

public class SpiderMan {

	public void 스파이더맨() {
		System.out.println("피터 파커");
	}
	
}
