package day12실습;

public class Spider2 extends SpiderMan{

	public void Andrew() {
		System.out.println("앤드류 가필드");
		System.out.println("❤️그웬 스테이시");
	}
	
}
