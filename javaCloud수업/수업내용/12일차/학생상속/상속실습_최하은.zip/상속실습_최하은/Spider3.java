package day12실습;

public class Spider3 extends SpiderMan{
	public void Tom() {
		System.out.println("톰 홀랜드");
		System.out.println("❤️MJ");
	}
}
