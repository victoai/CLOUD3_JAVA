package day12.실습;

public class Car extends Vehicle {

	public Car(String name) {
		super(name);
	}

	public void fuel() {
		System.out.println(name + "의 연료를 넣고 있습니다");
	}

}
