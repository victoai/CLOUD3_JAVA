package day12.실습;

public class VehicleMain {

	public static void main(String[] args) {

		Vehicle car = new Car("자동차");
		Vehicle bike = new Bicycle("자전거");

		Vehicle[] list = new Vehicle[2];
		list[0] = car;
		list[1] = bike;

		for (int i = 0; i < list.length; i++) {
			list[i].move();
			list[i].stop();

			if (list[i] instanceof Car) {
				Car c = (Car) list[i];
				c.fuel();
				System.out.println("=====================");
			} else if (list[i] instanceof Bicycle) {
				Bicycle b = (Bicycle) list[i];
				b.pedal();
			}
		}

	}

}
