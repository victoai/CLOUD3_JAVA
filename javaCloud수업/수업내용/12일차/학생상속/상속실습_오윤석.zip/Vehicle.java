package day12.실습;

public class Vehicle {

	String name;

	public Vehicle(String name) {
		this.name = name;
	}

	public void move() {
		System.out.println(name + "을 타고 이동합니다");
	}

	public void stop() {
		System.out.println(name + "이(가) 멈췄습니다");
	}

}
