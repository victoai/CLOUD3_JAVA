package day12.실습;

public class Bicycle extends Vehicle {

	public Bicycle(String name) {
		super(name);
	}

	public void pedal() {
		System.out.println(name + "의 페달을 밟고 있습니다");
	}

}
