package day12.오전실습;

public class LbStudents extends Students
{
    private int cls;
    private int sub1num;
    private int sub2num;
    private String sub1;
    private String sub2;
 
    public LbStudents(String name, int gendernum, int grade, int cls, int sub1, int sub2)
    {
    	super(name, gendernum, grade);
    	
        this.cls = cls;
        this.sub1num = sub1num;
        this.sub2num = sub2num;
    }
    
    public void sub()
    {
    	switch (sub1num)
    	{
	    	case 1: 
	    		sub1 = "생활과 윤리";
	    		break;
	    	case 2: 
	    		sub1 = "윤리와 사상";
	    		break;
	    	case 3: 
	    		sub1 = "한국지리";
	    		break;
	    	case 4: 
	    		sub1 = "세계지리";
	    		break;
	    	case 5: 
	    		sub1 = "동아시아사";
	    		break;
	    	case 6: 
	    		sub1 = "세계사";
	    		break;
	    	case 7: 
	    		sub1 = "경제";
	    		break;
	    	case 8: 
	    		sub1 = "정치와 법";
	    		break;
	    	default: 
	    		sub1= "ERROR";
	    		break;
    	}
    	
    	switch (sub2num)
    	{
	    	case 1: 
	    		sub2 = "생활과 윤리";
	    		break;
	    	case 2: 
	    		sub2 = "윤리와 사상";
	    		break;
	    	case 3: 
	    		sub2 = "한국지리";
	    		break;
	    	case 4: 
	    		sub2 = "세계지리";
	    		break;
	    	case 5: 
	    		sub2 = "동아시아사";
	    		break;
	    	case 6: 
	    		sub2 = "세계사";
	    		break;
	    	case 7: 
	    		sub2 = "경제";
	    		break;
	    	case 8: 
	    		sub2 = "정치와 법";
	    		break;
	    	default: 
	    		sub2= "ERROR";
	    		break;
    	}
    	
    	if (sub1 == sub2)
    	{
    		sub1= "ERROR";
    		sub2= "ERROR";
    	}
    }
        
    public void printLbSubInfo()
    {
    	sub();
    	
    	printInfo();
    	System.out.println("학급: 문과" + cls + "반");
        System.out.println("선택과목 1: " + sub1);
        System.out.println("선택과목 2: " + sub2);
    }
}