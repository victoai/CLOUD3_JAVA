package day11실습;

import java.util.Calendar;
import java.util.Scanner;

public class managemain {

	static int idx = 0;
	static Manage[] arr = new Manage[0];

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		loop: while (true) {
			System.out.println("1.등록 2.삭제 3.조회 4.변경 5.종료");
			int num = Integer.parseInt(sc.nextLine());

			switch (num) {
			case 1:
				System.out.println("작성자 이름을 입력하세요");
				String name = sc.nextLine();
				System.out.println("제목을 입력하세요");
				String title = sc.nextLine();
				System.out.println("내용을 입력하세요");
				String desc = sc.nextLine();
				arr = createSchedule(arr, name, title, getDate(), desc);
				break;

			case 2:
				System.out.println("어떤 인덱스의 일정을 삭제하시겠습니까?");
				int deleteIndex = Integer.parseInt(sc.nextLine()) - 1;
				arr = deleteSchedule(arr, deleteIndex);
				break;

			case 3:
				selectSchedule();
				break;

			case 4:
				System.out.println("변경할 일정의 인덱스를 입력하세요");
				int updateIndex = Integer.parseInt(sc.nextLine()) - 1;
				updateSchedule(arr, updateIndex, sc);
				break;

			case 5:
				System.out.println("프로그램 종료");
				break loop;
			default:
				System.out.println("잘못된 입력입니다");
			}
		}
		sc.close();

	}

	public static Manage[] createSchedule(Manage[] arr, String name, String title, String date, String desc) {
		Manage newarr = new Manage(name, title, date, desc);
		Manage[] newarrs = new Manage[arr.length + 1];

		for (int i = 0; i < arr.length; i++) {
			newarrs[i] = arr[i];
		}
		newarrs[arr.length] = newarr;
		idx++;
		System.out.println("등록 성공");
		return newarrs;
	}

	public static Manage[] deleteSchedule(Manage[] arr, int deleteIndex) {
		if (deleteIndex < 0 || deleteIndex >= arr.length) {
			System.out.println("잘못된 입력입니다");
			return arr;
		}

		Manage[] newarrs = new Manage[arr.length - 1];
		for (int i = 0, j = 0; i < arr.length; i++) {
			if (i != deleteIndex) {
				newarrs[j++] = arr[i];
			}
		}
		idx--;
		System.out.println("일정 삭제 성공");
		return newarrs;
	}

	public static void selectSchedule() {
		if (idx == 0) {
			System.out.println("아무런 일정도 없습니다");
		}
		for (int i = 0; i < idx; i++) {
			System.out.println((i + 1) + ". " + arr[i].toString());
		}
	}

	public static void updateSchedule(Manage[] arr, int updateIndex, Scanner sc) {
		if (updateIndex < 0 || updateIndex >= arr.length) {
			System.out.println("잘못된 입력입니다");
		} else {
			System.out.println("어떤 정보를 수정하시겠습니까?\n 이름 제목 상세내용 날짜");
			String input = sc.nextLine();
			if (input.equals("이름")) {
				System.out.println("수정할 이름을 입력하세요");
				String newname = sc.nextLine();
				Manage search = arr[updateIndex];
				search.Setname(newname);
				System.out.println("변경완료");
			} else if (input.equals("제목")) {
				System.out.println("수정할 제목을 입력하세요");
				String newtitle = sc.nextLine();
				Manage search = arr[updateIndex];
				search.Setname(newtitle);
				System.out.println("변경완료");
			} else if (input.equals("날짜")) {
				System.out.println("날짜를 수정합니다");
				String newdate = getDate();
				Manage search = arr[updateIndex];
				search.setdate(newdate);
				System.out.println("변경완료");
			} else if (input.equals("상세내용")) {
				System.out.println("수정할 내용을 입력하세요");
				String newdesc = sc.nextLine();
				Manage search = arr[updateIndex];
				search.setdesc(newdesc);
				System.out.println("변경완료");
			} else {
				System.out.println("잘못된 입력입니다");
			}
		}
	}

	public static String getDate() {
		Calendar cal = Calendar.getInstance();
		return String.format("%d/%02d/%02d %02d:%02d", cal.get(Calendar.YEAR), // 현재 연도
				cal.get(Calendar.MONTH) + 1, // 현재 월 (0부터 시작하므로 1을 더함)
				cal.get(Calendar.DATE), // 현재 날짜
				cal.get(Calendar.HOUR_OF_DAY), // 현재 시각 (24시간 형식)
				cal.get(Calendar.MINUTE)); // 현재 분
	}

}
