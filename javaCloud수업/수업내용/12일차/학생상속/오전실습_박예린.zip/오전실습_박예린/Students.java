package day12.오전실습;

public class Students
{
	protected String name; 
	protected int gendernum;
	protected String gender;
	protected int grade;
 
    public Students(String name, int gendernum, int grade)
    {
        this.name = name;
        this.gendernum = gendernum;
        this.grade = grade;
    }
    
    public void gender()
    {
    	switch (gendernum)
    	{
	    	case 1: 
	    		gender = "남성";
	    		break;
	    	case 2: 
	    		gender = "여성";
	    		break;
	    	default: 
	    		gender= "ERROR";
	    		break;
    	}
    }

    public void printInfo()
    {
    	gender();
    	
    	System.out.println("이름: " + name);
        System.out.println("성별: " + gender);
        System.out.println("학년: " + grade + "학년");
    }
}