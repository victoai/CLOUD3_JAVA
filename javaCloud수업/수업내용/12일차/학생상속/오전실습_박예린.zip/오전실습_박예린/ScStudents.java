package day12.오전실습;

public class ScStudents extends Students
{
    private int cls;
    private int sub1num;
    private int sub2num;
    private String sub1;
    private String sub2;
 
    public ScStudents(String name, int gendernum, int grade, int cls, int sub1, int sub2) 
    {
    	super(name, gendernum, grade);
    	
        this.cls = cls;
        this.sub1num = sub1num;
        this.sub2num = sub2num;
    }
    
    public void sub()
    {
    	switch (sub1num)
    	{
	    	case 1: 
	    		sub1 = "물리";
	    		break;
	    	case 2: 
	    		sub1 = "화학";
	    		break;
	    	case 3: 
	    		sub1 = "생명과학";
	    		break;
	    	case 4: 
	    		sub1 = "지구과학";
	    		break;
	    	default: 
	    		sub1= "ERROR";
	    		break;
    	}
    	
    	switch (sub2num)
    	{
	    	case 1: 
	    		sub2 = "물리";
	    		break;
	    	case 2: 
	    		sub2 = "화학";
	    		break;
	    	case 3: 
	    		sub2 = "생명과학";
	    		break;
	    	case 4: 
	    		sub2 = "지구과학";
	    		break;
	    	default: 
	    		sub2= "ERROR";
	    		break;
    	}
    	
    	if (sub1 == sub2)
    	{
    		sub1= "ERROR";
    		sub2= "ERROR";
    	}
    }
        
    public void printScSubInfo()
    {
    	sub();
    	
    	printInfo();
    	System.out.println("학급: 이과" + cls + "반");
        System.out.println("선택과목 1: " + sub1);
        System.out.println("선택과목 2: " + sub2);
    }
}