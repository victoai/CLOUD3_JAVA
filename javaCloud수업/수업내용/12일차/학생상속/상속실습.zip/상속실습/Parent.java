package 상속실습;

public class Parent {

	String name;
	String info;
	
	public Parent() {
		
	}
	
	public Parent(String name, String info) {
		this.name = name;
		this.info = info;
	}
	
	public String toString() {
		return name + info;
	}
}
