package 상속실습;

public class TestMain {
    public static void main(String[] args) {
        Parent p = new Parent("김개똥", "개똥이임");
        Son s = new Son("김아무개", "김아무개임", 4);


        Parent p1 = s; //업캐스팅 변수 p1은 본래 Son Type이지만 Parent 타입을 참조함
        System.out.println();
        System.out.println("업캐스팅 후");

        System.out.println("업캐스팅된 p1: " + p1.toString());

        System.out.println();
        System.out.println("다운캐스팅 후 고유메소드 출력");
        //p1.sonHello(); // 업캐스팅 상태에서는 호출 불가
        
        
        if(p1 instanceof Son) {
            Son p2 = (Son)p1; // 다운 캐스팅 변수 p2는 현재 Parent 타입을 참조하지만 다운 캐스팅으로 Son 타입을 참조하도록 함
            p2.sonHello();
        }
    }
}
