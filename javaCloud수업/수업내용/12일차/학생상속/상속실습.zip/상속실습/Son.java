package 상속실습;

public class Son extends Parent{

	int age;
	public Son(String name, String info, int age) {
		super(name, info);
		this.age = age;
	}
	
	public void sonHello() {
		System.out.println("안녕");
	}
	
	public String toString() {
		return name + info + age;
	}
	
	
	
	
	
}
