package day12.오전실습;

public class Car {
	public void 부릉부릉() {
		System.out.println("자동차는 부릉부릉 달린다💨💨💨");
	}
}
