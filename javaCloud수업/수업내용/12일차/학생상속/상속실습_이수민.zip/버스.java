package day12.오전실습;

public class 버스 extends Car{
	public void 탑승자() {
		System.out.println("버스는 많은 사람을 태운다");
	}
}
