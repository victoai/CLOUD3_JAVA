package day12.오전실습;

public class 유치원버스 extends 버스{
	public void 탑승자() {
		System.out.println("많은 유치원생이 탄다");
	}
}
