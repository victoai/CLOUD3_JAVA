package day12.실습;

public class Pisces {
	
	private int num;
	private String name;
	
	public Pisces(int num, String name) {
		this.num = num;
		this.name = name;
	}
	
	public void printInfo() {
		System.out.println("번호 :" + num);
		System.out.println("이름 :" + name);
	}
	
}
