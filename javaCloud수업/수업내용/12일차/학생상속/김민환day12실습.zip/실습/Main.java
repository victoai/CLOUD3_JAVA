package day12.실습;

public class Main {

	public static void main(String[] args) {
		
		Pisces p = new Pisces(1, "상어");
		Fish f = new Fish(2, "광어", "test");
		
		p.printInfo();
		f.fishInfo();
		
		
		//업캐스팅
		System.out.println("업캐스팅===============");
		Pisces p1 = f;
		p1.printInfo();
		//p1.fishInfo(); // 부모형으로 참조하였을 경우 자식의 모든 내용이 보이지 않는 것을 확인하기 
		
		
		//다운캐스팅
		System.out.println("다운캐스팅===============");
		/*
		Fish ff = (Fish)p1;
		ff.printInfo();
		ff.fishInfo();
		*/
		if (p1 instanceof Fish) { // instanceof로 확인 후 다운캐스팅 해보기
            Fish ff = (Fish) p1; //다운캐스팅
            ff.fishInfo(); // 자식 클래스의 고유 메서드 호출 가능
        }else {
            System.out.println("다운캐스팅 불가능");
        }
	}

}
