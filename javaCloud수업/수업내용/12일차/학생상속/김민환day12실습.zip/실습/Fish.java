package day12.실습;

public class Fish extends Pisces{
	
	private String Info;
	
	public Fish(int num, String name, String info) {
		super(num, name);
        this.Info = info;
	}
	
	public void fishInfo() {
		printInfo();
		System.out.println("정보 :" + Info);
	}
	
}
