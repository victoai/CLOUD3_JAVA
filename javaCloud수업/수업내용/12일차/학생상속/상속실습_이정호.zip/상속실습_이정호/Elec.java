package day12.실습;

public class Elec extends Song {
	public Elec() {
		
	}
	public Elec(String artist, String name, String time, String date) {
		super(artist, name, time, date);
	}
	
	public void printElecSong() {
		System.out.println("장르 : 일렉트로닉 뮤직");
		printSong();
	}
}
