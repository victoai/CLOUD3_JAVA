package day12.실습;

public class Song {
	String artist; //아티스트
	String name; //곡 제목
	String time; //재생 길이
	String date; //발매일
	
	public Song() {
		
	}
	public Song(String artist, String name, String time, String date) {
		this.artist = artist;
		this.name = name;
		this.time = time;
		this.date = date;
	}
	
	public void printSong() {
		System.out.println("아티스트 : " + artist);
		System.out.println("곡 제목 : " + name);
		System.out.println("재생 길이 : " + time);
		System.out.println("발매일 : " + date);
	}
}
