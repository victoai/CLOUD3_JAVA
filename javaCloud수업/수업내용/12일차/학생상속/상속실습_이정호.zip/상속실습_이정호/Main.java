package day12.실습;

public class Main {

	public static void main(String[] args) {
		POP pop = new POP("Fool's Garden", "Lemon Tree", "3:11", "1995년 11월 3일");
		Elec elec = new Elec("Alan Walker", "Faded", "3:33", "2015년 12월 3일");
		
		pop.printPOPSong(); //팝 출력
		System.out.println("=======================");
		elec.printElecSong(); //일렉 출력
		
		System.out.println("=========업캐스팅=========");
		
		//업캐스팅
		Song song = pop;
		song.printSong();
		
		System.out.println("=========다운캐스팅========");
		
		//다운캐스팅
		POP pop2 = (POP)song;
		pop2.printPOPSong();

	}

}
