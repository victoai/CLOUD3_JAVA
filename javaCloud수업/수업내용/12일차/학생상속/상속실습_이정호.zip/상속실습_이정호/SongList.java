package day12.실습;

public class SongList {

	public static void main(String[] args) {
		Song s1 = new POP("Fool's Garden", "Lemon Tree", "3:11", "1995년 11월 3일");
		Song s2 = new Elec("Alan Walker", "Faded", "3:33", "2015년 12월 3일");
		
		Song[] list = new Song[2];
		list[0] = s1;
		list[1] = s2;

		for(int i = 0; i < list.length; i++) {
			if(list[i] instanceof Elec) {
				Elec temp = (Elec)list[i];
				temp.printElecSong();
			}
		}
	}

}
