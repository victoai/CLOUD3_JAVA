package day12.실습;

public class POP extends Song {
	public POP() {
		
	}
	public POP(String artist, String name, String time, String date) {
		super(artist, name, time, date);
	}
	
	public void printPOPSong() {
		System.out.println("장르 : 팝");
		printSong();
	}
}
