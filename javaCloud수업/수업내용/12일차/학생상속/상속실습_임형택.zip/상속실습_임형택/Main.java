package day12.상속실습_임형택;

public class Main {

	public static void main(String[] args) {
		//부모출력
		Is i = new Is("윤현기","1234");
		i.print부모();
		System.out.println("==========");
		
		//자식출력
		A a = new A("임형택","5678");
		
		a.print자식();
		System.out.println("==========");
		
		//업캐스팅
		Is ii = new A("가나","다라");
		
		ii.print부모();
		
		ii.부모();
		
		//ii.자식(); 안됨
		
		System.out.println("==========");

		//다운캐스팅
		
		A aa = (A)ii;
		
		aa.부모();
		
		aa.자식();
		
	}

}
