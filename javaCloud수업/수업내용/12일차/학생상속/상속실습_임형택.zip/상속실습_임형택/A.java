package day12.상속실습_임형택;

public class A extends Is{
	
	public A() {
		
	}
	
	public A(String id, String pw) {
		super(id,pw);
	}
	
	public void 자식() {
		System.out.println("자식이다");
	}
	
	public void print자식() {
		print부모();
	}
	
}
