package day12.상속실습_임형택;

public class Is {
	
	private String id;
	private String pw;
	
	public Is() {
		
	}
	
	public Is(String id, String pw) {
		this.id = id;
		this.pw = pw;
	}
	
	public void print부모() {
		System.out.println(id+pw);
	}
	
	public void 부모() {
		System.out.println("부모이다");
	}
	
}
