package day12.실습;

public class FruitMain {

	public static void main(String[] args) {

		Fruit f1 = new Fruit("Apple", "새콤 달콤", 5);
		Fruit f2 = new Fruit("Banana", "달다구리", 7);
		goodqualityFruit gf1 = new goodqualityFruit("Strawberry", "새콤 달콤", 8, "상급");
		goodqualityFruit gf2 = new goodqualityFruit("Lemon", "새콤 새콤", 4, "최상급");
		
	       // 업캐스팅
        Fruit f3 = new goodqualityFruit("Orange", "새콤 달콤", 6, "최상급");
        
		
		f1.printFruit();
		f2.printFruit();
		f3.printFruit();
		System.out.print("\n============================================");
		gf1.gqFruitPrint();
		gf2.gqFruitPrint();
        // 다운캐스팅
        if (f3 instanceof goodqualityFruit) {
            goodqualityFruit gf3 = (goodqualityFruit) f3;
            gf3.gqFruitPrint();
        }
		
	}

}
