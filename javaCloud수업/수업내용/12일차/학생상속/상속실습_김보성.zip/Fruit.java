package day12.실습;

public class Fruit {

		String name;
		String taste;
		int rating;
		
		public Fruit() {
			
		}
		
		public Fruit( String name, String taste, int rating ) {
			this.name = name;
			this.taste = taste;
			this.rating = rating;
		}
		/*
		//getter
		public String getName() {
			return name;
		}
		
		public String getTaste() {
			return taste;
		}
		
		public int getRating() {
			return rating;
		}
		
		//setter
		*/
		//print
		public void printFruit() {
			System.out.print( "\n 이름 : " + name
					+" | " + " 맛 : " + taste
					+" | " + " 평점 : " + rating);
		}
		
}
