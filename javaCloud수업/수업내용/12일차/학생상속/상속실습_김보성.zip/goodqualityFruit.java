package day12.실습;

class goodqualityFruit extends Fruit{
	
	String quality;
	
	// 생성자
	public goodqualityFruit( String name, String taste, int rating, String quality ) {
		super(name, taste, rating);	// 부모클래스 호출
		this.quality = quality;
	
	}

	public void gqFruitPrint() {
		printFruit();
		System.out.print( " | "+" 품질 : " + quality);
	}
	
	
}
