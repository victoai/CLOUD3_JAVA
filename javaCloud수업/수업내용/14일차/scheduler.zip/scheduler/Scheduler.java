package day15.scheduler;

public interface Scheduler {
	public void getNextCall();
    public void sendCallToAgent();


}
