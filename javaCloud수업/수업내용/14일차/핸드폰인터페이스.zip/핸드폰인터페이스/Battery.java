package day15.인터페이스;

public interface Battery {	
	public void getEnergy();
}
