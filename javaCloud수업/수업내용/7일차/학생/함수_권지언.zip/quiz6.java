package day07;

public class quiz6 {

	public static void main(String[] args) {
		
		System.out.println(message());

	}

	public static String message() {
		String comment = "응원합니다!";
		return comment;
	}
}
