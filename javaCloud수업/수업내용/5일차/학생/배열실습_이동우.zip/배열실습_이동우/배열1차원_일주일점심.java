package day05배열저장출력문제;

public class 배열1차원_일주일점심 {

	public static void main(String[] args) {
		
		
		String[] menu = {"짜장면", "김밥", "돈까스", "국밥", "햄버거", "떡볶이", "라면"};
		
		for(int i = 0; i < menu.length; i++) {
			System.out.println(menu[i]);
		}

	}

}
