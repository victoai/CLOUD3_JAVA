package day05배열저장출력문제;

public class 배열1차원_예상로또번호 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int [] lotto = {21, 20, 18, 15, 31, 11};
		
		System.out.println(lotto[0]);
		
		for(int i = 0; i < lotto.length; i++) {
			System.out.println(lotto[i]);
		}
	}

}
