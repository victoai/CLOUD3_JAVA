package day09;

import java.util.Scanner;

public class ex {
    public static void main(String[] args) {
        Product pr1 = new Product();
        Product pr2 = new Product();
        Product pr3 = new Product();
        Product pr4 = new Product();

        pr1.inputProduct("핸드폰", "전자제품", 10000, "설명1", 1);
        pr2.inputProduct("테이블", "가전제품", 5000, "설명2", 1);
        pr3.inputProduct("감자칩", "과자", 2000, "설명3", 1);
        pr4.inputProduct("이온음료", "음료", 8000, "설명4", 1);

        Order[] orList = new Order[10];
        Product[] prList = new Product[4];
        prList[0] = pr1;
        prList[1] = pr2;
        prList[2] = pr3;
        prList[3] = pr4;

        Scanner sc = new Scanner(System.in);
        int index = 0;
        int index_pr = prList.length;

        Boolean loop = true;

        while (loop) {
            System.out.println("--------------------------------");
            System.out.println("1.주문하기");
            System.out.println("2.주문 확인하기");
            System.out.println("3.종료");
            System.out.println("--------------------------------");
            int input = sc.nextInt();
            sc.nextLine();
            switch (input) {
                case 1:
                    orList[index] = new Order();
                    System.out.println("이름: ");
                    orList[index].setOrder_name(sc.nextLine());
                    System.out.println("주소: ");
                    orList[index].setAddr(sc.nextLine());
                    System.out.println("전화번호: ");
                    orList[index].setPhone(sc.nextLine());
                    for (int i = 0; i < index_pr; i++) {
                        System.out.println("--------------------------------");
                        prList[i].printProduct();
                    }
                    while (true) {
                        System.out.println("추가하고 싶은 상품의 이름을 입력해주세요 (종료:0)");
                        String order_name = sc.nextLine();
                        if (order_name.equals("0"))
                            break;
                        for (int i = 0; i < index_pr; i++) {
                            if (order_name.equals(prList[i].getName())) {
                                System.out.println("추가하고 싶은 수량을 입력해주세요");
                                int cnt = sc.nextInt();
                                sc.nextLine();
                                prList[i].setAmount(cnt);
                                orList[index].setProduct(prList[i]);

                            }
                            prList[i].setAmount(1);
                        }
                    }
                    index++;
                    break;
                case 2:
                    System.out.println("--------------------------------");
                    for (int i = 0; i < index; i++) {
                        orList[i].showInfo();
                    }
                    System.out.println("--------------------------------");

                    break;
                case 3:
                    System.out.println("종료합니다.");
                    loop = false;

                default:
                    break;
            }
        }

    }
}
