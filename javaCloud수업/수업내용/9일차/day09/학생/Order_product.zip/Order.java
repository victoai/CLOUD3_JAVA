package day09;

public class Order {
    /*
     * 주문번호
     * 주문상품(배열)
     * 배달주소
     * 고객이름
     * 전화번호
     * 결제금액
     */
    private int order_id; //
    private Product[] list = new Product[10]; //
    private String addr;
    

	private String order_name;
    private String phone;
    private int price; //
    private int index = 0;

    public Order(){
        this.order_id = rnd_id();
    }

    public int rnd_id(){
        return (int)Math.floor(Math.random()*10000);
    }

    public void setProduct(Product item){
        list[index] = item;
        index++;
    }
    
    public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getOrder_name() {
		return order_name;
	}

	public void setOrder_name(String order_name) {
		this.order_name = order_name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

    public void getList(){
        for(int i = 0;i<index;i++){
            System.out.println(this.list[i].getName());
        }
    }

    public void setPrice(){
        for(int i = 0;i<index;i++){
            this.price += this.list[i].getPrice()*this.list[i].getAmount();
        }
    }

    public void showInfo(){
        System.out.println("주문번호: "+ this.order_id);
        System.out.println("주문 이름: "+ this.order_name);
        System.out.println("주문 리스트: ");
        getList();
        System.out.println("주소: " + this.addr);
        System.out.println("전화번호: "+ this.addr);
        setPrice();
        System.out.println("결제금액: "+ this.price + "원");
        System.out.println("--------------------------------");
    }

}
