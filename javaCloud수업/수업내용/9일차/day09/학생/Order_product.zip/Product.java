package day09;

public class Product {

    private String name;
    private String type;
    private int price;
    private String info;
    private int amount;

    public void inputProduct(String name, String type, int price, String info, int amount) {
        this.name = name;
        this.type = type;
        this.price = price;
        this.info = info;
        this.amount = amount;
    }

    public void printProduct() {
        System.out.println("상품이름 : " + name);
        System.out.println("상품종류 : " + type);
        System.out.println("가격 : " + price);
        System.out.println("상품정보 : " + info);
        System.out.println("상품 개수 : " + amount);
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int i) {
        this.amount = i;
    }

}
