package day09_Latte;

public class Latte {
    private int 카페라떼 = 4500;  // 기본 카페라떼 가격
    private int 샷추가 = 1000; // 샷 추가 가격
    private int 바닐라시럽추가 = 1000; // 바닐라 시럽 추가 가격
    private int 사이즈업 = 1500; // 사이즈 업 가격
    private int 합계금액 = 0;

    // 각 항목의 수량
    private int 카페;
    private int 샷추가수량;
    private int 바닐라시럽추가수량;
    private int 사이즈업수량;

    public void input(int 카페, int 샷추가수량, int 바닐라시럽추가수량, int 사이즈업수량) {
        this.카페 = 카페;
        this.샷추가수량 = 샷추가수량;
        this.바닐라시럽추가수량 = 바닐라시럽추가수량;
        this.사이즈업수량 = 사이즈업수량;
    }

    public void calcTotal() {
        합계금액 = (카페라떼 * 카페) + (샷추가 * 샷추가수량) + (바닐라시럽추가 * 바닐라시럽추가수량) + (사이즈업 * 사이즈업수량);
    }

    public void printInfo() {
        System.out.println("카페라떼 : " + 카페 + "잔");
        System.out.println("샷 추가 : " + 샷추가수량+"번");
        System.out.println("바닐라 시럽 추가 : " + 바닐라시럽추가수량 + "번");
        System.out.println("사이즈 업 : " + 사이즈업수량+"번");
        System.out.println("합계 금액: " + 합계금액 + "원");
    }    
}
