package day09_Latte;

public class LatteTest {
    public static void main(String[] args) {
        Latte L = new Latte();
        
        L.input(1, 3, 5, 1);
        L.calcTotal();
        L.printInfo();
    }
}
