package day11.상속맛보기.부모로다루기;

public class 오윤석  extends Acorn{

	@Override
	public void dance() {
		// TODO Auto-generated method stub
		System.out.println("셔플");
	}
	
}
