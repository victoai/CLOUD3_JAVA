package day11.상속맛보기.부모로다루기;

public class 임형택 extends Acorn{

	@Override
	public void dance() {
	    System.out.println( "Baile de los Viejitos de Jarácuaro Michoacán México 입니다");
	}
}
