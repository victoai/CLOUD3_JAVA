package day11.상속맛보기.부모로다루기;

public class 김민환  extends Acorn {

}
