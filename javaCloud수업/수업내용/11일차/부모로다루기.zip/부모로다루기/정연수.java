package day11.상속맛보기.부모로다루기;

public class 정연수 extends Acorn {
  @Override
public void dance() {
	  System.out.println( "탈춤");
}
}
