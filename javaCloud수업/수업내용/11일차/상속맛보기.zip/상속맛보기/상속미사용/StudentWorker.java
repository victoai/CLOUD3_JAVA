package day10.상속맛보기.상속미사용;

public class StudentWorker {
	public void 말하기() {
		System.out.println("말한다");
	}
	
	public void  먹기() {
		System.out.println( "먹기");
	}
	
	public void  걷기() {
		System.out.println(" 걷기 ");
	}
	
	
	public void 잠자기() {
		System.out.println( "잠자기");
	}
	
	
	public void 공부하기() {
		System.out.println( "공부하기");
	}
	
	public void 일하기() {
		System.out.println("일하기");
	}

}
