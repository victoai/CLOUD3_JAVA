package day10.상속맛보기.상속;

public class Researcher extends Person {
	
	public void  연구하기() {
		System.out.println("연구하기");
	}

}
